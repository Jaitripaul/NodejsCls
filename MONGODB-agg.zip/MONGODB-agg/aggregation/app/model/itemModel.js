import mongoose from "mongoose";

const itemSchema = new mongoose.Schema({
  item_name: {
    type: String,
    required: true,
  },
  price: {
    type: String,
    required: true,
  },
  qty: {
    type: Number,
    required: true,
  },
  date_of_bill: {
    type: String,
    required: true,
  },
});



const itemModel = mongoose.model("employees", itemSchema);
export default itemModel;
