import express from "express";
import itemController from "../Controller/itemController.js";
const router = express.Router();

router.post("/add-item", itemController.additem);
router.get("/items", itemController.allitem);

router.get('/match',itemController.match)


export default router;
