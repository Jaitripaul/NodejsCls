import itemModel from "../model/itemModel.js";
class itemController {
  async additem(req, res) {
    try {
      
      const item = new itemModel(req.body);
      const data = await item.save();
      res.status(201).json({
        status: true,
        message: "item added successfully",
        data: data,
      });
    } catch (error) {
      res.status(500).json({
        status: false,
        error: "Internal Server Error",
        message: error.message,
      });
    }
  }
  async allitem(req, res) {
    try {
      const data = await itemModel.find();
      res.status(200).json({
        status: true,
        message: "fetch All item successfully",
        data: data,
      });
    } catch (error) {
      res.status(500).json({
        status: false,
        error: "Internal Server Error",
        message: error.message,
      });
    }
  }
  async match(req, res) {
    try {
      const data = await itemModel.aggregate([
        // {
        //   $match:{
        //     // $or: [
        //     //   { name: { $regex: req.query.name, $options: "i" } },
        //     //   { email: { $regex: req.query.email, $options: "i" } }
        //     // ]
        //     gender:"female",
        //     department:"Marketing"
        //   }
        // },

        // {
        //   $project:{
           
        //     name:0   // without name all field show 
        //     //  name:1  // only name show
        //   }
        // }

        // { $match:{ gender:'male'}}, 

         { 
          $group:{
             _id:'$department.name',
              totalEmployees: { $sum: 1 },
              totalSalaries: { $sum:'$salary'}
           
          }
         }
        // { $sort:{ salary:-1}},
        // {
        //   $limit: 10
        // },

        // {
        //   $addFields:{
        //     fullName: { $concat: ["$name", " ", "$gender"] },
        //     category:"nodejs"
        //   }
        // }

        // {
        //   $skip:6
        // }
      ]);
      res.status(200).json({
        status: true,
        message: "fetch All item successfully",
        data: data,
      });
    } catch (error) {
      res.status(500).json({
        status: false,
        error: "Internal Server Error",
        message: error.message,
      });
    }
  }

  
}
export default new itemController();
