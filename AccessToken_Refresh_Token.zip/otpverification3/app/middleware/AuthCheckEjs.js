const jwt = require("jsonwebtoken");

const AuthcheckEjs = (req, res, next) => {
  if (req.cookies && req.cookies.userToken) {
    jwt.verify(
      req.cookies.userToken,
      process.env.JWT_ACCESS_TOKEN_SECRET_KEY,
      (err, decoded) => {
        if (err) {
          // If token expired, try refreshing using refresh token
          if (err.name === "TokenExpiredError" && req.cookies.refreshToken) {
            try {
              const decodedRefresh = jwt.verify(
                req.cookies.refreshToken,
                process.env.JWT_REFRESH_TOKEN_SECRET_KEY
              );

              // Issue new access token
              const newAccessToken = jwt.sign(
                { id: decodedRefresh.id, email: decodedRefresh.email },
                process.env.JWT_ACCESS_TOKEN_SECRET_KEY,
                { expiresIn: "15m" }
              );

              // Save new access token in cookies
              res.cookie("userToken", newAccessToken, { httpOnly: true });

              req.user = decodedRefresh;
              return next();
            } catch (refreshErr) {
              console.log("Invalid refresh token:", refreshErr.message);
              return res.redirect("/login");
            }
          } else {
            console.log("Invalid access token:", err.message);
            return res.redirect("/login");
          }
        } else {
          // valid access token
          req.user = decoded;
          return next();
        }
      }
    );
  } else {
    return res.redirect("/login");
  }
};

module.exports = AuthcheckEjs;
