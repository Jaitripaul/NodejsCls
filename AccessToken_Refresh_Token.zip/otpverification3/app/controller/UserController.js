const User = require("../model/UserModel");
const bcrypt = require("bcryptjs");
const jwt = require("jsonwebtoken");

// Temporary storage for refresh tokens (better: store in DB)
let refreshTokens = [];

class UserController {

  async CheckAuth(req, res, next) {
    try {
      if (req.user) {
        next();
      } else {
        res.redirect('/login');
      }
    } catch (err) {
      console.log(err);
    }
  }

  // get register page
  async registerPage(req, res) {
    res.render("register", { title: "register page" });
  }

  // post register
  async createuser(req, res) {
    try {
      const user = new User({
        name: req.body.name,
        email: req.body.email,
        password: bcrypt.hashSync(req.body.password, bcrypt.genSaltSync(10))
      });

      const result = await user.save();
      if (result) {
        console.log("register successfully");
        res.redirect("/login");
      } else {
        console.log("register failed");
        res.redirect("/");
      }
    } catch (err) {
      console.log(err);
    }
  }

  // get login
  async loginPage(req, res) {
    res.render("login", { error: null });
  }

  // post login
  async loggedCreate(req, res) {
    try {
      const { email, password } = req.body;
      const user = await User.findOne({ email });

      if (!user) {
        return res.render("login", { error: "User not found" });
      }

      const isMatch = await bcrypt.compare(password, user.password);
      if (!isMatch) {
        return res.render("login", { error: "Invalid credentials" });
      }

      // ✅ Create Access & Refresh Tokens
      const accessToken = jwt.sign(
        { id: user._id, name: user.name, email: user.email },
        process.env.JWT_ACCESS_TOKEN_SECRET_KEY,
        { expiresIn: "15m" } // short-lived
      );

      const refreshToken = jwt.sign(
        { id: user._id, email: user.email },
        process.env.JWT_REFRESH_TOKEN_SECRET_KEY,
        { expiresIn: "7d" } // long-lived
      );

      refreshTokens.push(refreshToken); // store refresh token

      // Save tokens in cookies
      res.cookie("userToken", accessToken, { httpOnly: true });
      res.cookie("refreshToken", refreshToken, { httpOnly: true });

      res.redirect("/dashboard");

    } catch (error) {
      console.error(error);
      res.status(500).send("Error logging in user");
    }
  }

  // refresh token route
  async refreshToken(req, res) {
    const refreshToken = req.cookies.refreshToken;
    if (!refreshToken) return res.status(401).json({ message: "Refresh token required" });
    if (!refreshTokens.includes(refreshToken)) return res.status(403).json({ message: "Invalid refresh token" });

    try {
      const decoded = jwt.verify(refreshToken, process.env.JWT_REFRESH_TOKEN_SECRET_KEY);
      const newAccessToken = jwt.sign(
        { id: decoded.id, email: decoded.email },
        process.env.JWT_ACCESS_TOKEN_SECRET_KEY,
        { expiresIn: "15m" }
      );

      res.cookie("userToken", newAccessToken, { httpOnly: true });
      res.json({ accessToken: newAccessToken });
    } catch (error) {
      return res.status(403).json({ message: "Invalid or expired refresh token" });
    }
  }

  // dashboard
  async dashBoard(req, res) {
    res.render("dashboard", { data: req.user });
  }

  // logout
  async logout(req, res) {
    try {
      res.clearCookie("userToken");
      res.clearCookie("refreshToken");

      // remove from stored tokens
      const refreshToken = req.cookies.refreshToken;
      refreshTokens = refreshTokens.filter(token => token !== refreshToken);

      res.redirect("/login");
    } catch (err) {
      console.log(err);
    }
  }
}

module.exports = new UserController();
