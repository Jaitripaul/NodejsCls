const { hsahePassword, comparePassword } = require('../middleware/AuthCheck'); 
const User = require('../model/UserModel');
const jwt = require('jsonwebtoken');
const bcrypt = require('bcryptjs');
const sendEmailVerificationOTP = require('../helper/sendEmailOtp');
const EmailVerifyModel = require('../model/otpModel');

// Temporary storage for refresh tokens (better: save in DB)
let refreshTokens = [];

class AuthApiController {

    // ------------------- Register -------------------
    async register(req, res) {
        try {
            const { name, email, password } = req.body;
            if (!name || !email || !password) {
                return res.status(400).json({ message: 'All fields are required' });
            }
            const existUser = await User.findOne({ email });
            if (existUser) {
                return res.status(400).json({ message: 'User already exist' });
            }

            const hashedPassword = hsahePassword(password);
            const user = await new User({
                name,
                email,
                password: hashedPassword
            }).save();

            sendEmailVerificationOTP(req, user);

            res.status(201).json({
                message: 'User created successfully and OTP sent to email',
                user: user
            });
        } catch (err) {
            console.log(err);
            res.status(500).json({ message: "Server error" });
        }
    }

    // ------------------- Verify OTP -------------------
    async verifyOtp(req, res) {
        try {
            const { email, otp } = req.body;
            if (!email || !otp) {
                return res.status(400).json({ status: false, message: "All fields are required" });
            }
            const existingUser = await User.findOne({ email });
            if (!existingUser) {
                return res.status(404).json({ status: "failed", message: "Email doesn't exists" });
            }
            if (existingUser.is_verified) {
                return res.status(400).json({ status: false, message: "Email is already verified" });
            }

            const emailVerification = await EmailVerifyModel.findOne({ userId: existingUser._id, otp });
            if (!emailVerification) {
                await sendEmailVerificationOTP(req, existingUser);
                return res.status(400).json({ status: false, message: "Invalid OTP, new OTP sent to email" });
            }

            const currentTime = new Date();
            const expirationTime = new Date(emailVerification.createdAt.getTime() + 2 * 60 * 1000);
            if (currentTime > expirationTime) {
                await sendEmailVerificationOTP(req, existingUser);
                return res.status(400).json({ status: "failed", message: "OTP expired, new OTP sent" });
            }

            existingUser.is_verified = true;
            await existingUser.save();
            await EmailVerifyModel.deleteMany({ userId: existingUser._id });

            res.status(200).json({ message: "Email verified successfully" });
        } catch (error) {
            console.error(error);
            res.status(500).json({ status: false, message: "Unable to verify email" });
        }
    }

    // ------------------- Login -------------------
    async login(req, res) {
        try {
            const { email, password } = req.body;
            if (!email || !password) {
                return res.status(400).json({ message: 'All fields are required' });
            }
            const user = await User.findOne({ email });
            if (!user) {
                return res.status(400).json({ message: 'User not found' });
            }
            if (!user.is_verified) {
                return res.status(401).json({ status: false, message: "Your account is not verified" });
            }

            const isMatch = await comparePassword(password, user.password);
            if (!isMatch) {
                return res.status(400).json({ message: 'Invalid credentials' });
            }

            // Generate Access & Refresh tokens
            const accessToken = jwt.sign(
                { _id: user._id, name: user.name, email: user.email },
                process.env.JWT_ACCESS_TOKEN_SECRET_KEY,
                { expiresIn: "15m" }   // short life
            );

            const refreshToken = jwt.sign(
                { _id: user._id, email: user.email },
                process.env.JWT_REFRESH_TOKEN_SECRET_KEY,
                { expiresIn: "7d" }   // longer life
            );

            refreshTokens.push(refreshToken); // store (better: DB)

            res.status(200).json({
                message: 'Login successful',
                accessToken,
                refreshToken,
                user: {
                    id: user._id,
                    name: user.name,
                    email: user.email
                }
            });

        } catch (err) {
            console.log(err.message);
           // res.status(500).json({ message: "Server error" });
        }
    }

    // ------------------- Refresh Token -------------------
    async refreshToken(req, res) {
        const { token } = req.body;
        if (!token) return res.status(401).json({ message: "Refresh token required" });
        if (!refreshTokens.includes(token)) return res.status(403).json({ message: "Invalid refresh token" });

        try {
            const decoded = jwt.verify(token, process.env.JWT_REFRESH_TOKEN_SECRET_KEY);
            const newAccessToken = jwt.sign(
                { _id: decoded._id, email: decoded.email },
                process.env.JWT_ACCESS_TOKEN_SECRET_KEY,
                { expiresIn: "15m" }
            );
            res.json({ accessToken: newAccessToken });
        } catch (error) {
            return res.status(403).json({ message: "Invalid or expired refresh token" });
        }
    }

    // ------------------- Dashboard -------------------
    async dashboard(req, res) {
        try {
            res.status(200).json({
                message: "Welcome to user dashboard",
                data: req.user
            });
        } catch (error) {
            console.log(error.message);
        }
    }
}

module.exports = new AuthApiController();
