const express=require('express')
const menuController = require('../controller/menuController')
const router=express.Router()



router.get('/',menuController.menupage)



module.exports=router