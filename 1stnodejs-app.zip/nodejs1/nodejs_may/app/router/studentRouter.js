const express=require('express')
const studentController = require('../controller/studentController')
const router=express.Router()



router.get('/',studentController.studentpage)



module.exports=router