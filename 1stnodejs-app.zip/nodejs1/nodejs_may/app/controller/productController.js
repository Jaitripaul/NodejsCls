class productController{

    async productpage(req,res){
        res.send('product page')
    }

}

module.exports=new productController()