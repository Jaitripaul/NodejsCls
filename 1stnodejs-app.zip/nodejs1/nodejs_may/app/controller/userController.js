class userController{

    async userpage(req,res){
        res.send('user page')
    }

}

module.exports=new userController()