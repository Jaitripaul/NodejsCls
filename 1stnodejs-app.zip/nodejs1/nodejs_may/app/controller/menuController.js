class menuController{

    async menupage(req,res){
        res.send('menu page')
    }

}

module.exports=new menuController()