class studentController{

    async studentpage(req,res){
        res.send('student page')
    }

}

module.exports=new studentController()