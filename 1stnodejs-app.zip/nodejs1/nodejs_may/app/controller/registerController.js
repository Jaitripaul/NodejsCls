class registerController{

    async registerpage(req,res){
        res.send('register page')
    }

}

module.exports=new registerController()