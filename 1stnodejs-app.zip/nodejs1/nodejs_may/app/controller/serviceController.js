class serviceController{

    async servicepage(req,res){
        res.send('service page')
    }

}

module.exports=new serviceController()