const express = require('express')

const app = express()



const userRouter=require('./app/router/userRouter');
const studentRouter=require('./app/router/studentRouter');
const menuRouter=require('./app/router/menuRouter');
const serviceRouter=require('./app/router/serviceRouter');
const productRouter=require('./app/router/productRouter');
const registerRouter=require('./app/router/registerRouter');

app.use('/user',userRouter);
app.use('/student',studentRouter);
app.use('/menu',menuRouter);
app.use('/service',serviceRouter);
app.use('/product',productRouter);
app.use('/register',registerRouter);





const port = 3008
// app.get('/',(req,res)=> {res.send('hello world');})

// app.get('/about',(req,res)=> {res.send('about page');})

// app.get('/open',(req,res)=>{res.send('open the page');})

// app.get('/user',(req,res)=>{res.send('user page');})

app.listen(port,()=>{
    console.log(`server is running port ${port}`);
}) 