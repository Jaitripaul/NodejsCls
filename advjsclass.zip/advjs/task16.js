// let date= new date
// console.log(date);
// let day = date.setday()

//Write a JavaScript function that returns a string that has letters in alphabetical order.
//Example string : 'webmaster'
//Expected Output : 'abeemrstw'
  function string1(str) {
    return str.split('').sort().join('');
  }
  
  let input = 'webmaster';
  let res = string1(input);
  
  console.log(res);
  
  

