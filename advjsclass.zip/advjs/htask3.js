function merge_array(arr1, arr2) {
  const merged = [...arr2, ...arr1];
  return [...new Set(merged)];
}

var array1 = [1, 2, 3];
var array2 = [2, 30, 1];
console.log(merge_array(array1, array2));  // [2, 30, 1, 3]

//34...
function asyncFunc(callback) {
  setTimeout(() => {
    callback("Done");
  }, 1000);
}

// Convert to Promise
function asyncFuncPromise() {
  return new Promise((resolve, reject) => {
    asyncFunc(result => {
      resolve(result);
    });
  });
}

asyncFuncPromise().then(console.log);  // "Done" after 1 second
//35..
function pluralize(word, count) {
  return count === 1 ? word : word + 's';
}

console.log(pluralize('apple', 1));  // apple
console.log(pluralize('apple', 5));  // apples

//37..
function minBy(arr, fn) {
  return arr.reduce((min, item) => {
    const val = fn(item);
    return val < min ? val : min;
  }, Infinity);
}
const arr = [1, 2, 3, 4];
console.log(minBy(arr, x => x * x));  // 1 (minimum of squares)
//38
function keysToLowerCase(obj) {
  const newObj = {};
  for (const key in obj) {
    if (obj.hasOwnProperty(key)) {
      newObj[key.toLowerCase()] = obj[key];
    }
  }
  return newObj;
}

const input = { Name: "Alice", AGE: 25 };
console.log(keysToLowerCase(input));  // { name: "Alice", age: 25 }

//39..
function isString(value) {
  return typeof value === "string";
}
console.log(isString("hello"));   // true
console.log(isString(123));       // false
