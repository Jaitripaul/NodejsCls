const isError=true;
let promiseVar = new Promise(function(resolve,reject){
    if(!isError){
        console.log("Resolved");
        resolve("it is resolved")
    }
    else{
        console.log("Rejected");
        reject("it is rejected")
    }
})
promiseVar
.then(res=>console.log("then block :",res))
.catch(err=>console.log("catch block:",err))


// class Employee {
//     constructor(empName, empId, empDesg, experience) {
//       this.empName = empName;
//       this.empId = empId;
//       this.empDesg = empDesg;
//       this.experience = experience;
//     }
  
//     getSalary() {
//       let salary;
  
//       if (this.empDesg === 'Manager') {
//         salary = this.experience > 8 ? 120000 : 95000;
//       } else if (this.empDesg === 'TL') {
//         salary = this.experience > 4 ? 85000 : 75000;
//       } else {
//         salary = 45000;
//       }
  
//       return `Employee: ${this.empName}, ID: ${this.empId}, Designation: ${this.empDesg}, Experience: ${this.experience} years, Salary: Rs.${salary}`;
//     }
//   }
  
//   // Example usage:
//   const emp1 = new Employee("Anjali", "E101", "Manager", 10);
//   const emp2 = new Employee("Rahul", "E102", "TL", 3);
//   const emp3 = new Employee("Priya", "E103", "Developer", 2);
  
//   console.log(emp1.getSalary());
//   console.log(emp2.getSalary());
//   console.log(emp3.getSalary());
  

// function show(){
//   console.log(" 2. inside the function before awaits");
//   let promise1 = new Promise((resolve,reject)=>{
//     setTimeout(()=> resolve("hello"),7000);
//   });

//   let result1= promise1;
 
//  console.log("3. Result of promise",result1);
//  console.log("4.Inside function after await");
// }
// console.log("1. Before function call");
// show();
// console.log("5.outside the function");

// using async and await 
// async function show(){
//   console.log(" 2. inside the function before awaits");
//   let promise1 = new Promise((resolve,reject)=>{
//     setTimeout(()=> {
//       console.log("**Promise resolve**");
//       resolve("hello")},7000);
//   });

//   let result1= await promise1; // wait until the promise resolves.
 
//  console.log("3. Result of promise",result1);
//  console.log("4.Inside function after await");
// }
// console.log("1. Before function call");
// show();
// console.log("5.outside the function");
// console.log("Hello");

// let data1 = "Hello world";;
// let data2 = "Hye world";
// let data3 = " hii";
// try {
//     console.log(data1)
//     console.log(dat);
//     console.log(data2);
// } catch(err) {
//   console.log("printing Error", err);
//   console.log(data3);
// }
// console.log("All printing done");

// async function fetchData(){
//   try{
//     const response = await fetch("https://jsonplaceholder.typicode.com/users",{
//       method : "GET",
//       headers: {
//         "Content-Type" : "application/json",
//       }
//     });
//     // console.log("response",response);
//     if (response.ok) {
//       const data = await response.json();
//         data.forEach(user =>{
//         console.log(`ID: ${user.id},username: ${user.username},email: ${user.email}`,);
//       });
//       // console.log("Data fetch",data);
//     }
//     else{
//       console.log("Request failed with status:",response.status);
//     }
//   }catch (error){
//     console.log("Error:",error);
//   }
  

// }
// fetchData();

async function postData(){
  try {
    const response = await fetch("https://jsonplaceholder.typicode.com/user",{
      method: 'Post',
      headers: {
        'content-Type': 'application/json',

      },
      body: JSON.stringify({name:'John',email:'john@gmail.com'}),
    }
  );
  if (response.ok){
    const data = await response.json();console.log("\n\nAfter post:",data);
  }else{
     console.log("Request failed with status:",response.status);
        }
      }catch (error){
        console.log("Error:",error);
      }
    }
    postData();
