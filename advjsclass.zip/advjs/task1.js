// const name= "Jaitri ";
//console.log(name); // print name 
// const days=["sun","mon","tues","wed"];
// console.log(days[0]);// print 0 position value .

// print given array value using for loop 
// let months=["jan","feb","mar","apr","may"];
// for(i=0;i<=4;i++)
//     {
//         console.log(months[i]);
//     }

// print table of 5  
// let a = 5;

// for(i=1;i<=10;i++)
// {

// let c = a*i;
//     console.log("5 x",i,"=",c);
// }
// using while loop print table of 9 ;
//let a=9;
//let i=1;
//while(i<=10)
//{
//  console.log(a,"x",i,"=",a*i);
//i++;
//}
// For in loop print array value 
// const color=['Red','Blue','Black','green','orange']
//      for(let x in color)
//      {
//         console.log(color[x]);
//      }


// for of loop print array value 
//  const color=['Red','Blue','Black','green','orange']
//      for(let x of color)
//      {
//         console.log(x);
//      }
// array object
// const user = {
//     fullname : "Jaitri Paul", 
//     age : 26,
//     address : "kolkata",
// }
// console.log(user.fullname) // print only fullname 

// const student = {
//     fullname : "Jaitri Paul",
//     Depertment : "CSE" ,
//     cgpa : 8.98 ,
//     isPass : true ,
// }
// student.rollno = 1 ,
// console.log(student)
// delete student.cgpa
// console.log(student)

// const student = [
//     { id: 's01', sname: "Happy", sclass: "VII", sroll: 1 },
//     { id: 's02', sname: "Sad", sclass: "VII", sroll: 2 },
//     { id: 's03', sname: "Smile", sclass: "VII", sroll: 3 }
// ];

// for (let x in student) {
//     console.log(student[x].sname, "reads in class", student[x].sclass);
// }

// const student =[
//      {
//          id : 's01', sname:"Happy",sclass:"VII",sroll:1
//      },

//       {
//         id : 's02', sname:"Sad",sclass:"VII",sroll:2
//       } ,

//       {
//         id : 's03', sname:"Smile",sclass:"VII",sroll:3
//       }]
//       for(let x of student)
//      console.log(x.sname,"reads in class ",x.sclass) 

// const student = [
//     { id: 's01', sname: "Happy", sclass: "VII", sroll: 1 },
//     { id: 's02', sname: "Sad", sclass: "VII", sroll: 2 },
//     { id: 's03', sname: "Smile", sclass: "VII", sroll: 3 }
// ];

// for (let i = 0; i < student.length; i++) {
//     console.log(student[i].sname, "reads in class", student[i].sclass);
// }

// const student = [
//     { id: 's01', sname: "Happy", sclass: "VII", sroll: 1 },
//     { id: 's02', sname: "Sad", sclass: "VII", sroll: 2 },
//     { id: 's03', sname: "Smile", sclass: "VII", sroll: 3 }
// ];

// let i = 0;
// while (i < student.length) {
//     console.log(student[i].sname, "reads in class", student[i].sclass);
//     i++;
// }

// const student = [
//     { id: 's01', sname: "Happy", sclass: "VII", sroll: 1 },
//     { id: 's02', sname: "Sad", sclass: "VII", sroll: 2 },
//     { id: 's03', sname: "Smile", sclass: "VII", sroll: 3 }
// ];

// let i = 0;
// do {
//     console.log(student[i].sname, "reads in class", student[i].sclass);
//     i++;
// } while (i < student.length);
// let num =[1,2,3,4,5,6,7,8,9,10];
// let len = num.length ;
// for(let x in num ){
//   console.log(num[len-1-x]);
// }

// 

// Write a js program to find gradation of mark of a student. If in a particular subject the student got
// i. Equal or greater than 90, he will get Grade A+ 
// ii. Less than 90 and equal and greater than 80, he will get Grade A 
// iii. Less than 80 and equal and greater than 60, he will get Grade B 
// iv. Less than 60 and equal and greater than 40, he will get Grade D 
// v. Less than 40, then Grade D, that mean fail.



// let num = 75 ;
// if(num >= 90)
// {
//   console.log("He will get Grade A+");
// }
// else if(num >= 80)
// {
//   console.log("He will get Grade A");
// }
// else if(num >= 60)
// {
//   console.log("He will get Grade B");
// }
// else if(num >=40 )
// {
//   console.log("He will get Grade C");
// }
// else
// {
//   console.log("He will Fail");
// }


// let a=10;
// let b=2;
// console.log(a,'+',b,'=',a+b);
// console.log(a,'-',b,'=',a-b);
// console.log(a,'*',b,'=',a*b);
// console.log(a,'/',b,'=',a/b);
// console.log(a,'%',b,'=',a%b);
// console.log(a,'^',b,'=',a**b);

// let year = 2015;
// if (year % 4 == 0) {
//   if (year % 100 != 0) {
//     console.log(" This year is  leap year")

//   }
//   else {
//     if (year % 400 == 0) {
//       console.log("This year is  a leap year")
//     }
//     else {
//       console.log("This year is not  leap year");

//     }
//   }


// }
// else {
//   console.log("This year is not  leap year");
// }

// Write a program which has a function to find out minimum among three numbers.
// let a = 10;
// let b = 17;
// let c = 8;
// if(a < b && a< c){
//   console.log("a is minimum");
// } 
// else if(b < c && b< a){
//   console.log("b is minimum");
// }
// else 
// {
//   console.log("c is minimum");
// }


// Write a program to check whether a number is divisible by 7 and 13 or not

// let num = 49;
// if ( num% 7=== 0 && num%13 === 0) 
// {
//   console.log('yes');
// }
// else 
// {
//   console.log('no');
// }

// Write a js program to find the eligibility of admission for a professional course based on the following criteria:
// Either, marks in maths>= 65 , marks in physics>=55 and marks in chemistry>=50
// or, total in maths and physics >=140 and total in three subject>=190


//   let maths = 70;
//   let physics = 70;
//   let chemistry = 80;
//   let a = (maths >= 65 && physics >= 55 && chemistry >= 50);

// //  // Total marks conditions
//  let mp = maths + physics;
//  let mpc = maths + physics + chemistry;
//  let b = (mp >= 140 && mpc >= 190);

// // // Check eligibility
//  if ( a || b) 
//   {
//     console.log("Eligible for admission.");
    
//   } 
//  else 
//  {
//      console.log("Not eligible for admission.");
//  }

// Write a JS program to input basic salary of an employee and calculate gross salary according to given 
// conditions. Basic Salary <= 10000 : HRA = 20%, DA = 80% Basic Salary is between 10001 to 20000 :
//  HRA = 25%, DA = 90% Basic Salary >= 20001 : HRA = 30%, DA = 95%

// Program to calculate gross salary based on basic salary

//Define the basic salary
// let basicSalary = 30000;

// let hra, da, grossSalary;

// // Calculate HRA and DA based on conditions
// if (basicSalary <= 10000) {
//     hra = 0.20 * basicSalary;
//     da = 0.80 * basicSalary;
// } else if (basicSalary <= 20000) {
//     hra = 0.25 * basicSalary;
//     da = 0.90 * basicSalary;
// } else {
//     hra = 0.30 * basicSalary;
//     da = 0.95 * basicSalary;
// }

// // // Calculate gross salary after assigning HRA and DA
//  grossSalary = basicSalary + hra + da;

// // // Display the result
// console.log('Basic Salary: ₹$',basicSalary);
//  console.log('HRA: ₹$',hra);
//  console.log("DA: ₹$",da);
// console.log('Gross Salary: ₹$',grossSalary);


// Create a program in Js that will ask the user to enter the total number of telephone calls made 
// in a particular month. 
// Here, "number of telephone calls" means "number of minutes." After receiving the total 
//  number of phone calls made in a month, the program will calculate and print the payable amount 
//  (for that month) as per the given call rate using Switch method:
// The first 200 phone calls are free every month.
// The next 300 calls are charged at Rs 0.50 per minute.
// Rest calls (after 500 calls or minutes) are charged at a rate of Rs 1.20 per minute.
     
//  let call = 100;
//  let amount=0;
//  if(call<=200)
//  {
//     console.log( 'free for this  month');
//  }
//  else if (call<=500)
//  {
//     amount=200*0 +(call - 200 ) *0.50
//     console.log('Total Amount :',amount);
//  }
//  else
//  {
//     amount = 200*0 + 300*0.50 +(call - 500)*1.20
//     console.log('Total Amount :',amount);

//  }


// Write a JS program to input electricity unit charge and calculate the total electricity 
// bill according to the given condition: 
// For first 50 units Rs. 0.50/unit
//  For next 100 units Rs. 0.75/unit
//  For next 100 units Rs. 1.20/unit 
// For unit above 250 Rs. 1.50/unit 
// An additional surcharge of 20% is added to the bill. 

// let unit = 500;
// let bill = 0;
// if(unit<= 50)
// {
//     bill=(25*0.50)
// }
// else if(unit<=150)
// {
//     bill =(25*50 + (unit -50)*0.75)
// }
// else if(unit<=250)
//     {
//         bill =(25*50 + 100*0.75 +(unit-150)*1.20)
//     }
// else (unit > 250)
// {
//     bill =(25*50 + 100*0.75 +100*1.20+(unit - 250)*1.50)

// }
// let payable = bill + (bill * 0.20)
// console.log(' bill : ',bill)
// console.log('Total bill : ',payable)









