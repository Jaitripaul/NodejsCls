// let arr=["a","b","c","d","e","f","g","h","i","j"]
// for(let i=0;i<=3;i++)
// {
//     let pattern=""
//     for(let j=0;j<=i;j++)
//     {
//         pattern+=arr[j]+""
//     }
//     console.log(pattern);
// }

// for(let i=0;i<=3;i++)
// {
//     let pattern=""
//     let count=0;
//     for(let j=0;j<=i;j++)
//     {
//         if(count%2==1)
//         {
//         pattern+=1+" "+0+" ";

//         }
//          else{
//         console.log(pattern+=1+" "+0+"");
//             }
//     }
// }


for (let i = 0; i <= 3; i++) {
    let pattern = ""
    for (let j = 0; j <= i; j++) {
        if (j % 2 == 1) {
            pattern += 1 + " ";
        }
        else {
            pattern += 0 + " ";
        }
        console.log(pattern);

    }
    console.log("\n");
}




