// let rows = 5; // You can change this to any number

// for (let i = 1; i <= rows; i++) {
//     let str = '';
//     for (let j = 1; j <= i; j++) {
//         str += '* ';
//     }
//     console.log(str);
// }

// let rows1 = 5; // Change this number for more/less rows

// for (let i = rows1; i >= 1; i--) {
//     let str = '';
//     for (let j = 1; j <= i; j++) {
//         str += '* ';
//     }
//     console.log(str);
// }



// let rows2= 5; // You can change this to any number

// for (let i = 1; i <= rows2; i++) {
//     let str = '';
//     for (let j = 1; j <= i; j++) {
//         str += '* ';
//     }
//     console.log(str);
// }

// let rows3 = 5; // Change this number for more/less rows

// for (let i = rows3; i >= 1; i--) {
//     let str = '';
//     for (let j = 1; j <= i; j++) {
//         str += '* ';
//     }
//     console.log(str);
// }

 let rows = 5; // You can change this to any number

 for (let i = 4; i <= 1; i++) {
    let str = '';
    for (let j = 1; j <= i; j++) {
        str += '* ';
    }
    console.log(str);
}