

// const world;
//  hello="world";
//  console.log(hello)

// function display(){
//     var a ="Hi";
//     {
//         var b = "Good Night";
//         console.log(a,b)
//     }
//     console.log(a,b)
// }
// display()


// let num = 25;
// num>=0
// ?(num>0?console.log("positive number"):console.log("zero"))
//  : console.log("negative")  

let dayCount=1;
switch(dayCount)
case 1 :