

let n = 100;
    const digits = n.toString()
    const power = digits.lenght;
    let sum ;
     for(let i = 0;i<power;i++){
        let digits = parseInt(digits[i]);
        sum += Math.pow(digits,power);
     }
        
     if(sum === n){
        console.log("It is an Armstrong number ");
     }
     else{
        console.log("It is not an Armstrong number ");
     }
     
