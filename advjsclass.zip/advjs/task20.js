//7
// function displayoddeven(n){
//     for(let i=1; i<=n;i++){
//         if(i%2===0){
//             console.log(i+":even");
//         }
//         else{
//             console.log(i+":odd");
//         }
//     }
// }
// displayoddeven(10);
// //8
// function displaydivisor(n){
//     for(let i=1; i<=n;i++)
//     {
//         if(n%i===0){
//             console.log(i);
//         }
//     }
// }
// displaydivisor(10);
// //9
// function displaySquarePattern(n){
//     for(let i=1;i<=n;i++)
//     {
//         const square = i*i;
//         const type=square % 2 === 0 ? "even" : "odd";
//         console.log(`Square of ${i} = ${square} : ${type}`);
//     }
// }
// displaySquarePattern(5);
// //10

// function printOddPaterrn(n){
//     let result = " ";
//     for(let i=1 ; i<=n; i++){   //if i+=3 , out put will be = 1#4#
//         if(i%2== 0){
//             console.log("#");
//             result++;
//         }
//         else 
//         {
//             console.log(n-1);
//         }
//     }

// }
// printOddPaterrn(3);//1#3#5#

//  function marks(n){
// if(n>=75)
// {
//     console.log("good");
// }
// else if(n>=50)
// {
//     console.log("Average");

// }
// else
// {
// console.log("poor");
// }
// }
// marks(90);

function marks(n){
    if(n>= 90)
    {
        console.log("Grade A");
    }
    else if ( n >= 75)
     {
        console.log ("Grade B");
     }
     else if ( n>= 50)
     {
        console.log ("Grade C");
     }
     else
     {
        console.log("grade D");
     }
}
marks(56);