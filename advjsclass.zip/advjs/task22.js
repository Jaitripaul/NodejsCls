// console.log("hii");
// console.error("Error");
// console.warn("Warning");
// function showAlert(){
//     alert("Message");
// }

//after alert use
// let btn=document.getElementById('btn');
// function showAlert(){
//     alert("Message");
//     console.error("Error");
//     console.warn("Warning");
// }
// btn.addEventListener('click',showAlert);
// let form=document.querySelector("form");

// let username=document.querySelector('#uname');
// let email=document.querySelector('#mail');
// form.addEventListener('submit',submitHandler);
// function submitHandler(event){
//     event.preventDefault();
//     let unameValue=username.value;
//     let mailValue=email.value;
//     console.log("Username",unameValue,"Email",mailValue)
// }

let btn = document.getElementById('btn');
        function showAlert() {
            alert("Message");
            console.error("Error");
            console.warn("Warning");
        }
        btn.addEventListener('click', showAlert);
        let form = document.querySelector("form");

        let username = document.querySelector('#uname');
        let email = document.querySelector('#mail');
        let display=document.getElementById("displayData");
        console.log("display",display)
        form.addEventListener('submit', submitHandler)

        function submitHandler(event) {
            event.preventDefault();
            let unameValue = username.value;
            let mailValue = email.value;
            console.log("Username", unameValue, "Email", mailValue)
            let dataDiv=document.createElement("div")
            dataDiv.innerHTML=`
            <h3>Username:${unameValue}</h3>
            <p>Email:${mailValue}</p>
            <p>_________________<p>
            `
            display.appendChild(dataDiv);
        }