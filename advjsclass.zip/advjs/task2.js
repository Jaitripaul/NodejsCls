// function sum(x,y,z){
//     let result= x+y+z ;
//     console.log("sum result:",result);
// }
// sum(20,34,10);
// let add =function(a,b,c){
//     let result= a+b+c ;
//     console.log(" add result:",result);
// }
// add(10,12,21);    

//Arrow function

// let show = () => {
//     console.log('Hello');
// }
// show();
 
// let square = num => num*num
 
// let result=square(5);
// console.log(result)
// // add two value;
// let add=(a,b)=>a+b

// let sum=add(5,7)
// console.log(sum)
//arrow function is a higher order funtion .
// higher order function - another funtion and variable parameter.
//first order funtion only variable as parameter.(annonymous fuction and named funtion) 
// first order function is called 'call back funtion'. 

// predefind funtion - push,pop,shift,unshift,splice,slice,
// 1) push - add value into the end of  array. it show lenght of array and also return value , add multiple value,
//      let arr=[1,2,3,4];
//      let len=arr.push(34,5)
//      console.log(arr,len);

// // 2)unshift- add value into the front of array, it show lenght of array and also return value, add multiple value  

//  len=arr.unshift(34,5)
// console.log(arr,len);

// // 3) pop -

// let popped=arr.pop()
// console.log(arr,"Remove",popped);
// // 4) shift - 
// let shifted=arr.shift()
// console.log(arr,"shift",shifted);


//Splice (index,no of element to be remove, add value)
let arr1=[2,45,3,6,8,7]
// arr1.splice(1,2,10,5) // add two value index 1 also remove 2 value 
// arr1.splice(1,0,10,5) // without remove adding two value index 1 
// arr1.splice(1,4) // without adding remove value  
// console.log(arr1);
let sliced = arr1.slice(1,4)
console.log(sliced)