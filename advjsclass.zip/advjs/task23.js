function calculateResult() {
    
    let totalMarks = bengali + english + physics + chemistry + maths;
    let percentage = (totalMarks / 500) * 100;

   
    let grade;
    if (percentage >= 90) {
        grade = "AA";
    } else if (percentage >= 80) {
        grade = "A+";
    } else if (percentage >= 70) {
        grade = "A";
    } else if (percentage >= 60) {
        grade = "B+";
    } else if (percentage >= 50) {
        grade = "B";
    } else if (percentage >= 40) {
        grade = "C";
    } else {
        grade = "D";
    }

    document.getElementById('result').innerHTML =
        `Total Marks: ${totalMarks}/500<br> +
        Percentage: ${percentage.toFixed(2)}%<br>+
        Grade: ${grade}`;
}

