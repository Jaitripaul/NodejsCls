// for(i=1;i<=10;i++){
//     let mult=10*i;
//     let multi1=20*i;
//     let str = (i+ " " +mult+ " " +multi1);
//     console.log(str);
// }

//   let n = 3 
//   result= "";
// for(let i=n; i>=1;i--){
//  result +=i;
// }
// console.log(result);

// console.log(output);

// let n=4;
// let output="";
// for(let i=1;i<=n;i++)
// {
//   output +=i;
//   for(let j=1;j<=i;j++){
    
//   output +="@";
// }
// }
// console.log(output);


// let n = 3;
// let str = "";
// let sum = 0;
// for(let i = n; i>= 1; i--) {
//        str +=(i%3 === 0 ? "X" : i)+"";  
// }
//  console.log(str );

// let n = 9;
// let divide = "Divide: ";
// let notDivide = "Not Divide: ";

// for (let i = 1; i <= n; i++) {
//   if (n % i === 0) {
//     divide += i + "#";
//   } else {
//     notDivide += i + "#";
//   }
// }

// console.log(divide);
// console.log(notDivide);


// let n = 2456;
// let sum = 0;

// for (let i = 1; i <= 4; i++) {
//   let digit = n % 10;      // Get last digit
//   sum += digit;            // Add to sum
//   n = Math.floor(n / 10);  // Remove last digit
// }

// console.log(sum);



// let str = "HelloWorld";

// if (str.length > 5) {
//   console.log("Long");
// } else {
//   console.log("Short");
// }


// let str = "moo zoom";


// let count = 0;


// for (let i = 0; i < str.length; i++) {
//   if (str[i] === 'm') {
//     count++;
//   }
// }

//console.log("Count of m=" + count);


// function countXY(str) {
//   let countX = 0;
//   let countY = 0;

//   for (const ch of str) {
//     if (ch === 'x') {
//       countX++;
//     } else if (ch === 'y') {
//       countY++;
//     }
//   }

//   console.log(`x=${countX} y=${countY}`);
// }

// // Test cases
// countXY("x+y+xy+4x=7");    // Expected Output: x=3 y=2
// countXY("ax+cz+dx=0");     // Expected Output: x=2 y=0

// function printIndexes(str) {
//   for (let i = 0; i < str.length; i++) {
//     if (str[i] === 'a' || str[i] === 'b') {
//       console.log(str[i] + " at index:" + i);
//     }
//   }
// }

// // Test cases
// printIndexes("abcaa");
// // Expected Output:
// // a at index:0
// // b at index:1
// // a at index:3
// // a at index:4

// console.log("---");

// printIndexes("cdeghBannba");
// // Expected Output:
// // a at index:6
// // b at index:9
// function removeFirstChar(str) {
//   let newStr = str.substring(1); // Removes the first character
//   console.log(newStr);
// }

// // Test case
// removeFirstChar("Perfect");  // Expected Output: erfect

// function removeFirstChar(str) {
//   let newStr = str.slice(1); // Removes the first character
//   console.log(newStr);
// }

// // Test case
// removeFirstChar("Perfect");  // Expected Output: erfect
// function removeFirstChar(str) {
//   let newStr = str.slice(1); // Removes the first character
//   console.log(newStr);
// }

// // Test case
// removeFirstChar("Perfect");  // Expected Output: erfect



// function replaceZWithX(str) {
//   let newStr = str.replaceAll('z', 'x'); // Replace all 'z' with 'x'
//   console.log(newStr);
// }

// // Test cases
// replaceZWithX("zoom");        // Expected Output: xoom
// replaceZWithX("sleep=zzz");   // Expected Output: sleep=xxx
// replaceZWithX("az+bz=4");     // Expected Output: ax+bx=4


// function removeAllM(str) {
//   let newStr = str.replaceAll('m', '');  // Remove all 'm' characters
//   console.log(newStr);
// }

// // Test cases
// removeAllM("my#mother");        // Expected Output: y#other
// removeAllM("am:pm:my:time");    // Expected Output: a:p:y:tie
// removeAllM("Hello123Hello123"); // Expected Output: Hello123Hello123 (no 'm' to remove)


// function getEvenIndexChars(str) {
//   let chars = str.split(''); // Convert string to array of characters
//   let evenChars = chars.filter((_, index) => index % 2 === 0); // Keep even index chars
//   let result = evenChars.join(''); // Join back to string
//   console.log(result);
// }

// // Test cases
// getEvenIndexChars("01234024");      // Expected Output: 0240
// getEvenIndexChars("JavaMasters");   // Expected Output: JvMses


// let str = "jaitrib";

// for (let i = 0; i < str.length; i++) {
//   if (str[i] === 'a') {
//     console.log("a at Index:" + i);
//   } else if (str[i] === 'b') {
//     console.log("b at Index:" + i);
//   }
// }


// let str1 = "Perfect";
// let newStr = [...str1].slice(1).join('');
// console.log(newStr);


// let str = "zoozz";
// let newStr = str.replace(/z/g, 'x'); // replaces all 'z' with 'x'
// console.log(newStr);

// let str = "my#mother";
// let newStr = str.replace(/m/g, ''); // removes all 'm' characters
// console.log(newStr);

// let str = "JavaMasters";
// let newStr = "";

// for (let i = 0; i < str.length; i++) {
//   if (i % 2 === 0) { // even index
//     newStr += str[i];
//   }
// }

// console.log(newStr);

// let str = "qw23BN**45g";
// let digits = "";

// for (let i = 0; i < str.length; i++) {
//   if (str[i] >= '0' && str[i] <= '9') {
//     digits += str[i];
//   }
// }

// console.log("Digits=" + digits);

// let str = "qw23BN**45gaa";
// let newStr = "";

// for (let i = 0; i < str.length; i++) {
//   let ch = str[i];
//   if (ch >= 'A' && ch <= 'Z') {
//     newStr += 'A';
//   } else if (ch >= 'a' && ch <= 'z') {
//     newStr += 'a';
//   } else if (ch >= '0' && ch <= '9') {
//     newStr += '0';
//   } else {
//     newStr += ch; // keep special characters like * as-is
//   }
// }

// console.log(newStr);


// let str = "qw2B**5g";
// let newStr = "";

// for (let i = 0; i < str.length; i++) {
//   let ch = str[i];
//   if ((ch >= 'a' && ch <= 'z') || (ch >= 'A' && ch <= 'Z')) {
//     newStr += ch.repeat(2); // double alphabets
//   } else if (ch >= '0' && ch <= '9') {
//     newStr += ch.repeat(3); // triple digits
//   }
//   // skip special characters
// }

// console.log(newStr);


// let str = "qw2B**5g";

// // Buckets for different character types
// let lower = "";
// let digit = "";
// let upper = "";

// for (let i = 0; i < str.length; i++) {
//   let ch = str[i];
//   if (ch >= 'a' && ch <= 'z') {
//     lower += ch;
//   } else if (ch >= '0' && ch <= '9') {
//     digit += ch;
//   } else if (ch >= 'A' && ch <= 'Z') {
//     upper += ch;
//   }
//   // Special characters are ignored
// }

// let result = lower + digit + upper;
// console.log(result);


// let str = "q#w2@B**5g#@**";
// let specialChars = "";

// for (let i = 0; i < str.length; i++) {
//   let ch = str[i];
//   if (!(/[a-zA-Z0-9]/.test(ch))) {
//     specialChars += ch;
//   }
// }

// console.log(specialChars);

// let str = "ABCDABCD"; // Example input (length = 12, even)
// let halfIndex = str.length / 2;
// let firstHalf = str.substring(0, halfIndex);

// console.log(firstHalf);

// let str = "JAVA"; // Example input
// let halfIndex = str.length / 2;
// let secondHalf = str.substring(halfIndex);

// console.log(secondHalf);


// let str = "JAVA"; // You can change this to any test case
// let len = str.length;
// let newStr = "";

// if (len % 2 === 0) {
//   // Even length: swap halves
//   let mid = len / 2;
//   newStr = str.slice(mid) + str.slice(0, mid);
// } else {
//   // Odd length: keep middle character fixed
//   let mid = Math.floor(len / 2);
//   let firstHalf = str.slice(0, mid);
//   let middleChar = str[mid];
//   let secondHalf = str.slice(mid + 1);
//   newStr = secondHalf + middleChar + firstHalf;
// }

// console.log(newStr);


// let str = "Java"; // Test input
// let len = str.length;

// if (len % 2 !== 0) {
//   console.log("No"); // String must be even length
// } else {
//   let half = len / 2;
//   let firstHalf = str.slice(0, half);
//   let secondHalf = str.slice(half);

//   if (firstHalf === secondHalf) {
//     console.log("Yes");
//   } else {
//     console.log("No");
//   }
// }

// let str = "ABCDE"; // Example input
// let midIndex = Math.floor(str.length / 2);
// let midChar = str[midIndex];

// console.log("Middle Char = " + midChar);
// console.log("Index = " + midIndex);


// let str1 = "James";
// let str2 = "jack";

// // Convert both strings to lowercase (or uppercase) for case-insensitive comparison
// if (str1.toLowerCase() === str2.toLowerCase()) {
//   console.log("Same");
// } else {
//   console.log("Not Same");
// }


// let str = "A1B2C3";
// let odd = "";
// let even = "";

// for (let i = 0; i < str.length; i++) {
//   if (i % 2 === 0) {
//     even += str[i]; // even index: 0, 2, 4
//   } else {
//     odd += str[i]; // odd index: 1, 3, 5
//   }
// }

// console.log("Odd:" + odd);
// console.log("Even:" + even);

// let str = "12ab1128d";
// let newStr = "";

// for (let i = 0; i < str.length; i++) {
//   if (str[i] === '1') {
//     newStr += '@';
//   } else if (str[i] === '2') {
//     newStr += '#';
//   } else {
//     newStr += str[i];
//   }
// }

// console.log(newStr);


// let str = "12049brt";
// let newStr = "";

// for (let i = 0; i < str.length; i++) {
//   let ch = str[i];
//   if (ch === '1') {
//     newStr += '@';
//   } else if (ch === '2') {
//     newStr += '#';
//   } else if (ch === '3') {
//     newStr += '&';
//   } else if ('456789'.includes(ch)) {
//     newStr += '$';
//   } else {
//     newStr += ch; // keep 0 and other characters as-is
//   }
// }

// console.log(newStr);


// let str = "BAD CAR"; // You can change the input
// let newStr = "";

// for (let i = 0; i < str.length; i++) {
//   let ch = str[i];
  
//   if (ch === 'A') {
//     newStr += 'X';
//   } else if (ch === 'B') {
//     newStr += 'Y';
//   } else if (ch === 'C' || ch === 'D') {
//     continue; // skip C and D
//   } else {
//     newStr += ch;
//   }
// }

// console.log(newStr);


// let str = "x+3+45+++";

// // Replace all sequences of two or more + with a single +
// let newStr = str.replace(/\++/g, '+');

// console.log(newStr);

// let str = "XXXXYYYYYABXXYY";

// // Replace all sequences of X or Y that appear consecutively (2 or more) with an empty string
// let newStr = str.replace(/([XY])\1+/g, ''); 

// console.log(newStr);

// let str = "AB CDJS";

// if (str.startsWith("ABCD")) {
//   console.log("Starts with ABCD");
// } else {
//   console.log("Does not start with ABCD");
// }


let str = "ABCDABCDABCD";  // You can change this to other test cases
let count = 0;
let target = "ABCD";

for (let i = 0; i <= str.length - target.length; i++) {
  if (str.substring(i, i + target.length) === target) {
    count++;
  }
}

console.log("Count of ABCD = " + count);
