//21.....
function swapCase(str) {
  let swapped = "";

  for (let i = 0; i < str.length; i++) {
    let char = str[i];

    if (char === char.toUpperCase()) {
      swapped += char.toLowerCase();
    } else {
      swapped += char.toUpperCase();
    }
  }

  return swapped;
}
let input = "The Quick Brown Fox";
let output = swapCase(input);
console.log(output);  // tHE qUICK bROWN fOX
//22...

var a = [
  [1, 2, 1, 24],
  [8, 11, 9, 4],
  [7, 0, 7, 27],
  [7, 4, 28, 14],
  [3, 10, 26, 7]
];

for (let i = 0; i < a.length; i++) {
  console.log("row " + i);
  for (let j = 0; j < a[i].length; j++) {
    console.log(" " + a[i][j]);
  }
}
//23....
function removeDuplicatesIgnoreCase(arr) {
  const lowerCaseSet = new Set();
  const result = [];

  for (const item of arr) {
    const lowerItem = typeof item === 'string' ? item.toLowerCase() : item;
    if (!lowerCaseSet.has(lowerItem)) {
      lowerCaseSet.add(lowerItem);
      result.push(item);
    }
  }
  return result;
}

// Example
const arr = ['a', 'A', 'b', 'B', 'a', 'C', 'c'];
console.log(removeDuplicatesIgnoreCase(arr));  // ['a', 'b', 'C']
//24...
function findLeapYears(startYear, endYear) {
  const leapYears = [];
  for (let year = startYear; year <= endYear; year++) {
    if ((year % 4 === 0 && year % 100 !== 0) || (year % 400 === 0)) {
      leapYears.push(year);
    }
  }
  return leapYears;
}

console.log(findLeapYears(2000, 2020));  

//25...
function binary_Search(arr, target) {
  let left = 0;
  let right = arr.length - 1;

  while (left <= right) {
    let mid = Math.floor((left + right) / 2);

    if (arr[mid] === target) {
      return mid;
    } else if (arr[mid] < target) {
      left = mid + 1;
    } else {
      right = mid - 1;
    }
  }

  return -1; // Not found
}

var items = [1, 2, 3, 4, 5, 7, 8, 9];
console.log(binary_Search(items, 1));  // 0
console.log(binary_Search(items, 5));  // 4

//26
function sumArrays(arr1, arr2) {
  const maxLength = Math.max(arr1.length, arr2.length);
  const result = [];

  for (let i = 0; i < maxLength; i++) {
    const val1 = arr1[i] || 0;
    const val2 = arr2[i] || 0;
    result.push(val1 + val2);
  }

  return result;
}

const array1 = [1, 0, 2, 3, 4];
const array2 = [3, 5, 6, 7, 8, 13];
console.log(sumArrays(array1, array2));  // [4, 5, 8, 10, 12, 13]

//28...
function cleanArray(arr) {
  return arr.filter(item => {
    return item !== null && item !== 0 && item !== '' && item !== false && item !== undefined && !Number.isNaN(item);
  });
}

const sample = [NaN, 0, 15, false, -22, '', undefined, 47, null];
console.log(cleanArray(sample));  // [15, -22, 47]

//29...
// function sortByTitle(arr) {
//   return arr.sort((a, b) => {
//     const titleA = a.title.toLowerCase();
//     const titleB = b.title.toLowerCase();
//     if (titleA < titleB) return -1;
//     if (titleA > titleB) return 1;
//     return 0;
//   });
// }

// const items = [
//   { title: "Banana", id: 2 },
//   { title: "apple", id: 1 },
//   { title: "Cherry", id: 3 }
// ];

// console.log(sortByTitle(items));

//30...

function mergeArrays(arr1, arr2) {
  return Array.from(new Set([...arr1, ...arr2]));
}

const array5 = [1, 2, 3];
const array6 = [2, 30, 1];
console.log(mergeArrays(array5, array6));  // [1, 2, 3, 30]


