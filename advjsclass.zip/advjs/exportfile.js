let greet ="Good Evening"

function display()
{
    console.log("Have a nice day");
}

class Abc{
    constructor(){
        console.log('Class Called');
    }
    showMsg()
    {
        console.log("Hello from Class");
    }
}
// default export 
export default Abc;
// named export 
export {display, greet};