
// const array1 = [1, 2, 3, 4];

// const initialValue = 0;
// const sumWithInitial = array1.reduce(
//   (accumulator, currentValue) => accumulator + currentValue,
//   initialValue,
// );

// console.log(sumWithInitial);
// // foreach 
// array1.forEach((element) => console.log(element));

//join
// const elements = ["Happy", "lucky", "smile"];

// console.log(elements.join());
// console.log(elements.join(""));
// console.log(elements.join("-"));

//concat
// const array1 = ["a", "b", "c"];
// const array2 = ["d", "e", "f"];
// const array3 = array1.concat(array2);

// console.log(array3);

//sort
// const months = ["March", "Jan", "June", "Aug"];
// months.sort();
// console.log(months);
// // inclue
// const array1 = [1, 2, 3];

// console.log(array1.includes(2));
// // Expected output: true

// const pets = ["cat", "dog", "bat"];

// console.log(pets.includes("cat"));
// // Expected output: true

// console.log(pets.includes("at"));
// // Expected output: false

// //indexof
// const beasts = ["ant", "bison", "camel", "duck", "bison"];

// console.log(beasts.indexOf("bison"));
// // Expected output: 1

// // Start from index 2
// console.log(beasts.indexOf("bison", 2));
// // Expected output: 4

// console.log(beasts.indexOf("giraffe"));
// // Expected output: -1

//Print the positive numbers only from the following array:   [-22, -45, 43, 12, 34, 87, -42, 13, -87]

// let arr3=[-22, -45, 43, 12, 34, 87, -42, 13, -87]

// let arr=arr3.filter(num=>num>0)
//  console.log("After filter;",arr);
//  for(let x in arr)
//     console.log("positive number",arr[x])

//  Let a number array contains 6 values. Increment all the elements of the array by 5

// let arr4=[2,5,7,8,9,6]
// let mappedarr=arr4.map(num=>num+5)
// console.log(mappedarr);

//change Grade property value using forEach (change the grade value to A+, if it is A or B, 
// otherwise change the grade value to B+)
// const students = [
//     { name: "Alice", grade: "A" },
//     { name: "Bob", grade: "B" },
//     { name: "Charlie", grade: "C" }
// ];
// students.forEach(student => {
//     if (student.grade === "A" || student.grade === "B") {
//         student.grade = "A+";
//     } else {
//         student.grade = "B+";
//     }
// });
// console.log(students);


// Increase the age of all users in an array of objects.
// Input:
// [
//     { name: "Alice", age: 25 },
//     { name: "Bob", age: 30 },
//     { name: "Charlie", age: 22 }
// ];

// const Employee= [
//     { name: "Alice", age: 25 },
//     { name: "Bob", age: 30 },
//     { name: "Charlie", age: 22 }
// ];
// let updateEmp=Employee.map(emp=> ({
//     name: emp.name ,
//     age: emp.age+1

// }));

// console.log(updateEmp);

const numbers = [10, 43, 76, 28, 33, 55];

const result = numbers.map(num => {
    if (num % 2 === 0) {
        return 'even';
    } else {
        return 'odd';
    }
});

console.log(result);
