// let person ={
//     fullname:"Jaitri Paul",
//     age: 24,
//     address:"Murshidabad",

// }
// let {address,fullname}=person;
// console.log(fullname,"Lives in",address)

// let person ={
//     fullname:{fname:"Jaitri",lname:"Paul"},
//     age: 24,
//     address:{city:"Murshidabad",pin:742137},

// }
// let {fname}=person.fullname;
// let{city}=person.address;
// console.log(fname,"Lives in",city)


// let user={
//     id:1,
//     name:"Leanne Graham",
//     username:"Bret",
//     email:"Sincere@april.biz",

//     address:{
//         street:"Kulas Light",
//         suite:"Apt.556",
//         city:"Gwenborough",
//         zipcode:"92998-3874",
//         geo:{
//             lat:"-37.3159",
//             lng:"81.1496"
//         }
//     },

//     phone:"1-770-736-8031*56442",
//     website:"hidegard.org",
//     company:{
//         cname:"Romaguera.-crona",
//         catchPhrase:"Multi-layered client-seever neural-net",
//         bs:"harness real-time e-markets"
//     }


// }
// let {name,username}=user;
// console.log("name:", name,"user name:", username)
// let {street,suite,city,zipcode}=user.address
// console.log(street,suite,city,zipcode)
// let{lat,lng}=user.address.geo
// console.log(lat,lng)


// let date = new Date()
// console.log(date);
// let time = date.getTime()
// console.log(time);
// let day = date.getDay()
// console.log(day);
// let month = date.getMonth()
// console.log(month);
// let hours = date.getHours()
// console.log(hours);
// let mint = date.getMinutes()
// console.log(mint);
// let seconds =date.getSeconds()
// console.log(seconds);
// let miliseconds = date.getMilliseconds()
// console.log(miliseconds);


//isNan , tostring , Number ,perseInt,toFixed,isInteger
// let num=12.34
// let res1 =isNaN(num);
// console.log(res);

// let str="jaitri"
// let res =isNaN(str);
// console.log(res);

// let num1= 12345;
// console.log(typeof(num1));

// let res2=toString(num1);
// console.log(typeof(res2));

// let num2="123";
// console.log(Number(num2),typeof(Number(num2)))
// console.log(parseInt(num2),typeof(parseInt(num2)))
// console.log(Number("10 20"),typeof(Number("10 20")))
// console.log(parseInt("10 20"),typeof(parseInt("10 20")))
// console.log(Number("10 abc"),typeof(Number("10 abc")))
// console.log(parseInt("10 abc"),typeof(parseInt("10 abc")))
// console.log(Number("abc 20"),typeof(Number("abc 20")))
// console.log(parseInt("abc 20"),typeof(parseInt("abc 20")))

// let num3 = 12.345
// console.log(num3.toFixed(4));
// console.log(num3.toFixed(2));
// console.log(Number.isInteger(num3));
// console.log(Number.isInteger(124));


// let person ={fname:"Jaitri",lname:"Paul"};
// function display(x){
//   return this.fname+" "+this.lname;

// }
// let callRes=display.call(person)
// console.log("call:",callRes);
// let applyRes=display.call(person)
// console.log("apply:",applyRes);
// //using function when call bind

// let bindRes=display.bind(person)
// console.log("bind:",bindRes());

// let person ={fname:"Jaitri",lname:"Paul"};
// function display(x){
//   return x+" " +this.fname+" "+this.lname;

// }
// let callRes=display.call(person,"hello")
// console.log("call:",callRes);
// // In apply using array for variable pass.
// let applyRes=display.apply(person,["hi"])
// console.log("apply:",applyRes);
// //using function when call bind

// let bindRes=display.bind(person,"hello1")
// console.log("bind:",bindRes());


// class Students{
//     constructor(name,cls,add){
//         this.sname= name;
//         this.scalss = cls;
//         this.add=add;
//     }
//     display(){ //prototype method
//         console.log(this.sname,"lives in ",this.add)
//     }
//     static welcome(){
//         console.log("welcome to Students class")
//     }
// }
// Students.welcome()
// let stud1=new Students("happy",10,"kolkata")
// stud1.display();

class Parent{
    constructor(){
        console.log("Parent class constructor")
    }
//     disply(){
//         console.log("Parent")
//     }
}
// //let obj1=new Parent();
class Child extends Parent{
constructor(){
    super();
    console.log("Child class constructor")
}
// display(){
//     console.log("Child")
// }
}
let obj1=new Child()
//obj1.display()

//Write a js program to create a class called ‘Rectangle’ with properties for width and height.
//  Include two methods to calculate rectangle area and perimeter. 
//Create an instance of the class ‘Reactangle’ class and calculate its area and perimeter



class Rectangle{
    constructor(width,height){
        this.x=width;
        this.h=height;
    }
area(){
   let result= this.x * this.h;
   console.log(result);

}
perimeter(){
    return 2*(this.x + this.h);
    
}
}
const rectangle1 = new Rectangle(5,4);
console.log("Width:", rectangle1.x);
console.log("Height:", rectangle1.h);
rectangle1.area();
// console.log("Area:", rectangle1.area());
console.log("Perimeter:", rectangle1.perimeter());

class Employee{
constructor(empName, empId, empDesg, experience){
    this.name =empName;
    this.id= empId;
    this.desg=empDesg;
    this.exp =experience;
}
salary()
{
    if(this.desg === "Manager")
    {
        if(this.exp >=8){
            return 120000;
        }
        else {
            
        }
    }
}
}