import DefaultClass from './exportfile.js'
import {display,greet} from './exportfile.js'

console.log("Hello, ",greet);

display()
display()
display()
let obj =new DefaultClass;
obj.showMsg();