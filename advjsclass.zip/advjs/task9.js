// //uppercase
// let msg="Jaitri";
// result= msg.toUpperCase()
// console.log(result);

// ///lowercase
// let msg1="Jaitri";
// result= msg.toLowerCase()
// console.log(result);

// //trim
// let msg2="    Jaitri    Paul    ";
// result= msg2.trim()
// console.log(result);
// console.log(result.charAt(3));
// //concat
// let msg3="Jaitri"  
// let msg4= "Paul"  ;
// let fName="Jaitri"+"Paul"
// result= fName.concat()
// console.log(result);
// //replace
let str="Hello";
// console.log(str.replace("H","W"));
console.log(str.replaceAll("l","A"));

// //slice

// let str1="JaitriPaul";
// console.log(str1.slice(1,2));

// let msg="    Hello everyone.      ";
// let result = msg.trim()
//                 .slice(0,-1)
//                 .toUpperCase();
// result = result.charAt(0).toLowerCase()+result.slice(1);
// console.log(result);

let msg="    Hello everyone.      ";
let result = msg.trim()
                .replace('.','')
                .toUpperCase();
result = result[0].toLowerCase()+result.slice(1);
console.log(result);
