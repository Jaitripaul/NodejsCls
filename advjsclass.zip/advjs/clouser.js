function showOuter() {
    let count = 0;
    function showInner(){
        count++;
        console.log(count);
    }
    return showInner;
}
let data = showOuter();
data();
data();
data();