// 1. Reverse a string
function reverseString(str) {
  return str.split('').reverse().join('');
}

let result = reverseString("jaitri");
console.log(result); // Output: "irtiaj"

// 2. Remove specified elements from the right of an array

function removeFromRight(arr, count) {
  return arr.slice(0, -count);
}

console.log(removeFromRight([1, 2, 3, 4, 5], 2)); // Output: [1, 2, 3]

//3.Reverse a number
function reverseNumber(num) {
  return parseInt(num.toString().split('').reverse().join(''));
}
let result2 = reverseNumber(1234);
console.log(result2);

// 4. Check if a string is a palindrome

function isPalindrome(str) {
  let reversed = str.split('').reverse().join('');
  return str === reversed;
}

// Example usage:
console.log(isPalindrome("madam"));      // true
console.log(isPalindrome("nurses run")); // false (space matters)
console.log(isPalindrome("Racecar"));    // false (case matters)

//5. Return string with letters in alphabetical order
function alphabetOrder(str) {
  return str.split('').sort().join('');
}
let result3 = alphabetOrder("webmaster");
console.log(result3);
 //6.Count Vowels in a String

function countVowels(str) {
  const vowels = 'aeiouAEIOU';
  let count = 0;

  for (let char of str) {
    if (vowels.includes(char)) {
      count++;
    }
  }

  return count;
}

// Example usage:
console.log(countVowels("The quick brown fox")); // Output: 5

//7. Return type of argument
function detectType(value) {
  return typeof value;
}

console.log(detectType(12));             // "number"
console.log(detectType("Hello"));        // "string"
console.log(detectType(true));           // "boolean"
console.log(detectType(undefined));      // "undefined"
console.log(detectType({}));             // "object"
console.log(detectType(function(){}));   // "function"

//8. Find second lowest and second greatest




//9. Odd or even from 0 to 15
for (let i = 0; i <= 15; i++) {
  let type = (i % 2 === 0) ? "even" : "odd";
  console.log(`${i} is ${type}`);
}

//10. Find the longest word in a string
function findLongestWord(str) {
  let words = str.split(' ');
  return words.reduce((longest, word) => word.length > longest.length ? word : longest, "");
}
console.log(findLongestWord("Web Development Class"));




let str = "abcaa";

for (let i = 0; i < str.length; i++) {
  if (str[i] === 'a') {
    console.log("a at Index:" + i);
  } else if (str[i] === 'b') {
    console.log("b at Index:" + i);
  }
}
