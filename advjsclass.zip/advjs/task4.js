// let arr=[5,7,9,10,34,65]
// let findingRule = (num)=>{
//     console.log("Value of num",num)
//     return num%2===0;
// }
// let found=arr.find(findingRule)
// console.log("After Find",found);
// let arr1=arr.filter(num=>num%2===0)
// console.log("After filter;",arr1);

// let employee=[
//     {
//         id:"e001", empName :'Rahul' , desg:'Manager' , empAge: 19
//     },
//     {
//         id:"e002", empName :'Raja' , desg:'Team Leader' , empAge : 18
//     },
//     {
//         id:"e003", empName :'Rani' , desg:'Manager',empAge : 15
//     },
//     {
//         id:"e004", empName :'Ramu' , desg:'peon',empAge : 21
//     }
 
// ]
//find Employee whose desg is manager
// let empManager=employee.find(emp=>emp.desg=='Manager')
// console.log(empManager);
//find All Manager using filter method
// let empManagers=employee.filter(emp=>emp.desg=='Manager')
// console.log(empManagers);
// let arr2=[34,87,23,12,56]
// let mappedarr=arr2.map(num=>num*2)
// console.log(mappedarr);
// arr2.forEach(num=>console.log(num*2))

let users=[
    {
        username:"John",location:"Kolkata",age:15
    },
    {
        username:"Rose",location:"Siliguri",age:18
    },
    {
        username:"Harry",location:"Howrah",age:25
    }
]
users.filter(usr=>{
    if(usr.age>=18)
        console.log(usr.username,"who stays at",usr.location,'is eligible to vote');
})