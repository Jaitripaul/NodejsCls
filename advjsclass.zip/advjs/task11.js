
let arr = [1, 2];
let arr1 = [2, 3, 4];

let result = arr1.map((val, index) => val + arr[index] );

console.log(result); 

