// Let you have a function which receives two parameter and calculate the value  of :-
// (ab2+b3-a5) / (a+b) and return it.
// Call the function with argument: a = 2, b = -1


// function calculate(a, b) {
//     const numerator = a * (b ** 2) + (b ** 3) - (a ** 5);
//     const denominator = a + b;
//     return numerator / denominator;
// }

// // Call the function with a = 2, b = -1
// const result = calculate(2, -1);
// console.log("Result:", result);

// Make a function named as calculation, it will receive two numbers and then find out addition, 
// subtraction, multiplication, division and remainder result of those numbers.  
// Then find those results for the given numbers:   12 and 8,   -20 and 7
// function calculation(a,b){
// console.log(`result for a=${a}, b=${b}`);
//    console.log("addition",a+b) ;
//    console.log("subtraction",a-b) ;
//    console.log("multiplication",a*b) ;
//    console.log("divition",a/b) ;
//    console.log("remainder",a%b) ;
   
     

// }
// calculation(12,8);
// calculation(-20,7);

// Make a function which will calculate the value of :  (a2+3ab3+a+b)/(a4-b ) and return the value 
// Now call the function when a=1, b=-1 and print the result.
// Expected output: -1

function calculate1(a, b) {
    let numerator1 =(a**2+3*a*b**3+a+b);
    let denominator1 =(a**4-b);
    return numerator1 / denominator1;
}

// Call the function with a = 1, b = -1
let result1 = calculate1(1,-1);
console.log("Result:", result1);


// Create a menu driven program where user has to submit their choice of calculation among 
// 4 available choices. 1st choice named as ‘sum’ will take 4 values, and calculate and print 
// the result of their addition. 2nd choice named as ‘multiply’ will take 3 values and calculate 
// and print the result of their multiplication. 3rd choice is maximum amd minimum 
// named as ‘max_min’, will take 3 values and print the numbers in descending order.
//  4th choice is ‘power’, it will take the base and power,
//  calculate the value and print that. Default will show, calculation failed. 

function menu()
switch(choice)
case 'sum':let a=2,b=4,c=3,d=5;
console.log("sum Result",a+b+c+d);
break;
case 'multiply':let x=2,y=4,z=3;
console.log("multi Result",x*y*z);
break;
case 'max_min':let e=12,f=3,g=6;
console.log("Max_MinResult",e<f&e<g);
break;
case 'Power':let h=12,i=3;
console.log("power",h**g);
break;