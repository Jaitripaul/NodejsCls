// const array1 = [13, 20, 33, 14];

// const initialValue = 0;
//  const sumWithInitial = array1.reduce(
//    (accumulator, currentValue) => if (accumulator>= currentValue){
//      console.log()
//    }
      
// );

// function sum(a,b,c)
// {
//     let result=a+b+c;
//     console.log(`${a}+${b}+${c}=${result}`);
    
// }
// sum(10,25,4);
// sum(10,8);

// function sum1(a,b,c)
// {
//      let result=a+b+c;
//     console.log(`${a}+${b}+${c}=${result}`);
//  }
//  sum1("Jaitri","Riya","Mina");
// sum1("Jaitri","Riya");

// function sum2(a=0,b=undefined,c=0)
// {
//     let result=a+b+c;
//     console.log(result);
    
//  }
//  sum2(10,13);
function show(...x)
{
    let result= 1;
     x.forEach(n=>result=result*n)
    console.log(result);
}
show(10,3);