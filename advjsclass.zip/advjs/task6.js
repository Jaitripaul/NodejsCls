//1. Remove duplicate elements from an array
// Input:  [1, 2, 2, 3, 4, 4, 5]
// Expected Output: [1, 2, 3, 4, 5]

// const numbers = [1, 2, 2, 3, 4, 4, 5];
// const seen = {}; // Object to track seen numbers

// const newNumbers = numbers.filter(num => {
//     if (seen[num]) {
//         return false; // If the number was seen before, filter it out
//     }
//     seen[num] = true; // Mark the number as seen
//     return true; // Keep the number
// });

//  console.log(newNumbers);

//2.............

// const staffsDetails = [
//     { name: "John", age: 26, salary: 4500, currency: "USD" },
//     { name: "Smith", age: 26, salary: 2500, currency: "USD" },
//     { name: "Merry", age: 25, salary: 3900, currency: "USD" },
//     { name: "Luna", age: 25, salary: 2200, currency: "USD" },
//     { name: "Ron", age: 24, salary: 3700, currency: "USD" }
// ];

// const highSalaryNames = staffsDetails.filter(staff => {
//     if (staff.salary >= 3000) {
//         console.log(staff.name); 
//         return true;
//     }
//     return false;
// });

//3
// Filter out odd numbers from an array using forEach
// Input: [11, 54, 72, 23, 87]
// Output: [11, 23, 87]
const num1 = [11, 54, 72, 23, 87];
num1.forEach(num => {
  if (num % 2 !== 0) {
 console.log(num)
  }
});


//4.........
// const technologies = ["Python", "JavaScript", "C++", "JAVA"];

// // Remove the second element ("JavaScript") and add two new technologies
// technologies.splice(1, 1, "React", "Node.js");

// // Sort the array alphabetically
// technologies.sort();

// console.log(technologies);

// ///5........
// const technologies1 = [
//     { id: 1, tech_name: "Python", description: "A high-level programming language" },
//     { id: 2, tech_name: "Java", description: "A widely-used object-oriented language" },
//     { id: 3, tech_name: "ReactJS", description: "A JavaScript library for UI development" },
//     { id: 4, tech_name: "Node.js", description: "A runtime environment for JavaScript" }
// ];

// const filteredTechs = technologies1.filter(tech => tech.tech_name.length > 5);

// // Print each object separately without brackets
// filteredTechs.forEach(tech => console.log(`id: ${tech.id}, tech_name: ${tech.tech_name}, description: ${tech.description}`));