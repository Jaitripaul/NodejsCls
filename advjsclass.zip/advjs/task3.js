const students = [
    {sname:"Tiya",sclass: "VI",sroll:1},
    {sname:"Mina",sclass: "VI",sroll:2},
    {sname:"Riya",sclass: "VI",sroll:3}
];
students.push({sname:"Tina" ,sclass: "VI",sroll:4});
console.log(students);
students.pop();
console.log(students);
students.unshift({sname:"Rinku" ,sclass: "VI",sroll:5});
console.log(students);
students.shift();
console.log(students);
let obj1 = {sname:"Rima",sclass: "VI",sroll:6}
let obj2 = {sname:"Rina",sclass: "VI",sroll:7}
students.splice(2,0,obj1,obj2);
console.log(students);
let sliced=students.slice(2,4);
console.log(sliced);