// //fibonacci series
// function fib(n){
//     let a=0,b=1;
//     for(let i=1;i<=n;i++){
//         console.log(a);
//         let next = a+b;
//         a=b;
//         b=next;
//     }
// }
// let n= 5;
// console.log("n=",n);
// fib(n);

// //prime number 
// let num=15;
// if(num <= 1){
//     console.log("num is prime number");
// }
// let count = 0;
// for(let i =1; i <=num ; i++){
//     if(num% i == 0) {
//         count ++ ;
//     }
// }
// if(count == 2){
//     console.log( "num is a prime number");
// }
// else{
//     console.log( "num is not a prime number");
// }

function isArm(n){
    let digits = n.toString().split("");
    let power = digits.lenght;
    let sum = digits.map(digit =>Math.pow(parseInt(digit),power)).reduce((a,b) =>a+b,0);

     if(sum == n){
        console.log("It is an Armstrong number ");
     }
     else{
        console.log("It is not an Armstrong number ");
     }

}   
isArm(153);
isArm(100); 
