//11....Check if a number is prime

function isPrime(num) {
  if (num <= 1) return false; // not prime
  for (let i = 2; i < num; i++) {
    if (num % i === 0) {
      return false; // divisible by i, so not prime
    }
  }
  return true; // no divisors found, prime
}

// Example usage:
console.log(isPrime(7));  // true
console.log(isPrime(10)); // false
console.log(isPrime(1));  // false

//13...to find the largest of five numbers.
function findLargest(a, b, c, d, e) {
  let largest = a;

  if (b > largest) {
    largest = b;
  }
  if (c > largest) {
    largest = c;
  }
  if (d > largest) {
    largest = d;
  }
  if (e > largest) {
    largest = e;
  }

  return largest;
}

console.log(findLargest(10, 25, 8, 30, 12)); // Output: 30
//14...
// Student marks data
const students = [
  { name: 'David', marks: 80 },
  { name: 'Vinoth', marks: 77 },
  { name: 'Divya', marks: 88 },
  { name: 'Ishitha', marks: 95 },
  { name: 'Thomas', marks: 68 }
];

// Function to calculate average marks
function calculateAverage(students) {
  let total = 0;
  for (let student of students) {
    total += student.marks;
  }
  return total / students.length;
}

// Function to determine grade from average marks
function getGrade(avg) {
  if (avg < 60) return 'F';
  if (avg < 70) return 'D';
  if (avg < 80) return 'C';
  if (avg < 90) return 'B';
  return 'A';
}

const averageMarks = calculateAverage(students);
const grade = getGrade(averageMarks);

console.log(`Average Marks: ${averageMarks.toFixed(2)}`);
console.log(`Grade: ${grade}`);

//15...

function getGrade(avg) {
  if (avg < 60) return 'F';
  else if (avg < 70) return 'D';
  else if (avg < 80) return 'C';
  else if (avg < 90) return 'B';
  else if (avg < 100) return 'A';
  else return 'Invalid average';
}
console.log(getGrade(75));

//16......

for (let i = 1; i <= 100; i++) {
  if (i % 3 === 0 && i % 5 === 0) {
    console.log("FizzBuzz");
  } else if (i % 3 === 0) {
    console.log("Fizz");
  } else if (i % 5 === 0) {
    console.log("Buzz");
  } else {
    console.log(i);
  }
}
//17...
for (let num = 100; num <= 999; num++) {
  let sum = 0;
  let temp = num;

  while (temp > 0) {
    let digit = temp % 10;
    sum += digit * digit * digit;
    temp = Math.floor(temp / 10);
  }

  if (sum === num) {
    console.log(num);
  }
}
//18.....

function isArray(input) {
  return Array.isArray(input);
}
console.log(isArray([1, 2, 3]));   // true
console.log(isArray("Hello"));    // false
console.log(isArray({a: 1}));     // false
//19...
var arr1 = [ -3, 8, 7, 6, 5, -4, 3, 2, 1 ];

arr1.sort(function(a, b) {
  return a - b;
});

console.log(arr1);  // Output: [-4, -3, 1, 2, 3, 5, 6, 7, 8]

//19....

var arr1 = [3, 'a', 'a', 'a', 2, 3, 'a', 3, 'a', 2, 4, 9, 3];

function findMostFrequent(arr) {
  let frequency = {};
  let maxFreq = 0;
  let mostFrequentItem;

  for (let item of arr) {
    frequency[item] = (frequency[item] || 0) + 1;

    if (frequency[item] > maxFreq) {
      maxFreq = frequency[item];
      mostFrequentItem = item;
    }
  }

  console.log(`${mostFrequentItem} ( ${maxFreq} times )`);
}

findMostFrequent(arr1);
