// Write a JavaScript program to remove specified elements from the right of a given array of elements.?
  function removeFromRight(arr, count) {
     return arr.slice(0, arr.length - count);
   }
   let numbers = [10, 20, 30, 40, 50];
  let result = removeFromRight(numbers, 3);
  
  console.log(result); 