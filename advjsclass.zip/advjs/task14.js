// let obj1={fname:"Jaitri",lname:"Paul"};
// let obj2={dist:"MSD",PO:"Kandi"};
// let obj3={road:"Bus stand",pincode:742137};
// let address={...obj1,...obj2,...obj3}
// console.log(address);


// let color=["red","green","blue","yellow"];
// let [color1,color2, ...x]=color;
// console.log(color1);
// console.log(x)
