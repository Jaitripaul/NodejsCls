const express = require('express');
const path = require('path');

const app = express();

// Set view engine and views directory
app.set('view engine', 'ejs');
app.set('views', path.join(__dirname, 'views'));

// Serve static files (like images, CSS, JS) from the public directory
app.use(express.static(path.join(__dirname, 'public')));

// Use product router
const productRouter = require('./app/router/productRouter');
app.use('/', productRouter);  // Ensure it handles the root or '/products'

const port = 3009;
app.listen(port, () => {
    console.log(`✅ Server is running on http://localhost:${port}`);
});
