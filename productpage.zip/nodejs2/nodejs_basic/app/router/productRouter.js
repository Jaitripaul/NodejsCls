const express = require('express');
const ProductController = require('../controller/ProductController');

const router = express.Router();

// Routes
router.get('/', ProductController.productpage);
router.get('/about', ProductController.aboutpage);

module.exports = router;
