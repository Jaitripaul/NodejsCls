class ProductController {

    async productpage(req, res) {
        const products = [
            {
                name: 'T-Shirt Classic',
                productSize: ['S', 'M', 'L', 'XL'],
                image: 'tshirt.jpg',
                category: 'Apparel',
                price: 599.99,
                productColor: ['Red', 'Blue','Green'],
                rating:' good'
            },
            {
                name: 'Running Shoes',
                productSize: ['7', '8', '9', '10'],
                image: 'shoes1.jpg',
                category: 'Footwear',
                price: 700.99,
                productColor: ['Black', 'White'],
                 rating:' good'
            },
            {
                name: 'Denim Jeans',
                productSize: ['28', '30', '32', '34'],
                image: 'public/images/jeans1.jpg',
                category: 'Apparel',
                price: 2000.99,
                productColor: ['Blue', 'Grey'],
                 rating:' good'
            },
            {
                name: 'Leather Jacket',
                productSize: ['M', 'L', 'XL'],
                image: 'public/images/jacket1.jpg',
                category: 'Outerwear',
                price: 89.99,
                productColor: ['Black'],
                 rating:' good'
            },

            {
                name: 'Sneakers Street',
                productSize: ['6', '7', '8'],
                image: 'public/images/sneakers1.jpg',
                category: 'Footwear',
                price: 599.99,
                productColor: ['Green', 'Yellow'],
                 rating:' good'
            },
            {
                name: ' Hoodie',
                productSize: ['M', 'L'],
                image: 'public/images/hoodie1.jpg',
                category: 'Apparel',
                price: 677.99,
                productColor: ['Black', 'White'],
                 rating:' good'
            },
            {
                name: 'Smartwatch X',
                productSize: [],
                image: 'public/images/smartwatch1.jpg',
                category: 'Electronics',
                price: 2000.99,
                productColor: ['Silver', 'Black'],
                 rating:' good'
            },
            {
                name: 'Backpack Pro',
                productSize: [],
                image: 'public/images/backpack1.jpg',
                category: 'Accessories',
                price: 34.99,
                productColor: ['Navy', 'Brown'],
                 rating:' good'
            },
            {
                name: 'Formal Shirt',
                productSize: ['M', 'L', 'XL'],
                image: 'public/images/shirt1.jpg',
                category: 'Apparel',
                price: 24.99,
                productColor: ['White', 'Blue'],
                 rating:' good'
            },
            {
                name: 'Casual Belt',
                productSize: ['M', 'L'],
                image: 'public/images/belt1.jpg',
                category: 'Accessories',
                price: 14.99,
                productColor: ['Brown', 'Black'],
                 rating:' good'
            },
            {
                name: 'Winter Gloves',
                productSize: ['S', 'M', 'L'],
                image: 'public/images/gloves1.jpg',
                category: 'Winterwear',
                price: 12.99,
                productColor: ['Grey', 'Black'],
                 rating:' good'
            },
            {
                name: 'Beanie Hat',
                productSize: ['One Size'],
                image: 'public/images/beanie1.jpg',
                category: 'Accessories',
                price: 9.99,
                productColor: ['Black', 'Red'],
                 rating:' good'
            },
            {
                name: 'Sunglasses Max',
                productSize: [],
                image: 'public/images/sunglasses1.jpg',
                category: 'Accessories',
                price: 49.99,
                productColor: ['Black'],
                 rating:' good'

            },
            {
                name: 'Yoga dress',
                productSize: ['S', 'M', 'L'],
                image: 'public/images/yogadress1.jpg',
                category: 'Fitness',
                price: 34.99,
                productColor: ['Purple', 'Black'],
                 rating:' good'
            },
            {
                name: 'Sports dress',
                productSize: ['S', 'M'],
                image: 'public/images/sportsbra1.jpg',
                category: 'Fitness',
                price: 19.99,
                productColor: ['Pink', 'Grey'],
                 rating:' good'
            },
            {
                name: 'Cap Classic',
                productSize: ['Adjustable'],
                image: 'public/images/cap1.jpg',
                category: 'Accessories',
                price: 11.99,
                productColor: ['Red', 'Blue'],
                 rating:' good'
            },
            {
                name: 'Loafers',
                productSize: ['8', '9', '10'],
                image: 'public/images/loafers1.jpg',
                category: 'Footwear',
                price: 44.99,
                productColor: ['Tan', 'Black'],
                 rating:' good'
            },
            {
                name: 'Windbreaker Jacket',
                productSize: ['M', 'L', 'XL'],
                image: 'public/images/windbreaker1.jpg',
                category: 'Outerwear',
                price: 59.99,
                productColor: ['Navy', 'Grey'],
                 rating:' avg'
            },
            {
                name: 'Graphic Tee',
                productSize: ['S', 'M', 'L','XL','XXl'],
                image: 'public/images/tee1.jpg',
                category: 'Apparel',
                price: 17.99,
                productColor: ['White', 'Black'],
                 rating:' good'
            },
            {
                name: 'Flip Flops',
                productSize: ['7', '8', '9'],
                image: 'public/images/flipflops1.jpg',
                category: 'Footwear',
                price: 9.99,
                productColor: ['Blue', 'Green'],
                 rating:' good'
            
            }
        ];

        res.render('product', {
            title: 'Product Page',
            products
        });
    }

    async aboutpage(req, res) {
        res.render('about', {
            title: 'About Page'
        });
    }
}

module.exports = new ProductController();
