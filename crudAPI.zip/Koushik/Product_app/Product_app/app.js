require("dotenv").config();
const express = require("express");
const app = express();

const dbcon = require("./app/config/dbConnection");
dbcon();

app.use(express.json());

const ApiRouter = require("./app/router/ApiRouter");
app.use(ApiRouter);

const port = 3008 || process.env.PORT;
app.listen(port, () => {
  console.log(`App is Running at port no ${port}`);
});
