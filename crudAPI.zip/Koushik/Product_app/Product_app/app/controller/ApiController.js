const Product=require("../model/product");

class ApiController
{
    async create(req,res)
    {
         try{
           const {name,price,size,color,desc,brand}=req.body

           const data=new Product({
            name,price,size,color,desc,brand
           })
           const result=await data.save()
           return res.status(201).json({
            status:true,
            message:"Data Create Sucessful",
            data:result

           })
        }

        catch(error)
        {
            res.status(500).json({
                message:error.message
            })
            
        }
    }


     async getdata(req,res)
      {
  
          try{
             const alldata=await Product.find()
             return res.status(200).json({
              status:true,
              message:"data get successfully",
              data:alldata
             })
          }catch(error){
              res.status(500).json({
                  message:error.message
              })
          }
  
      }




       async edit (req,res){
              try{
                  const id =req.params.id
                  const edit=await Product.findById(id)
      
                  res.status(200).json({
                      status:true,
                      message:'get single data',
                      data:edit
                  })
      
              }catch(error){
                   res.status(500).json({
                      message:error.message
                  })
              }
      
              
      
          }


          async update (req,res){
                  try{
                      const id =req.params.id
                      
                      const update=await Product.findByIdAndUpdate(id,req.body)
          
                      res.status(200).json({
                          status:true,
                          message:'data update successfully',
                      })
          
                  }catch(error){
                       res.status(500).json({
                          message:error.message
                      })
                  }
          
                  
          
              }


 async delete (req,res)
 {
                      try{
                          const id =req.params.id
                          
                          const update=await Product.findByIdAndDelete(id)
              
                          res.status(200).json({
                              status:true,
                              message:'data delete successfully',
                          })
              
                      }
                      catch(error){
                           res.status(500).json({
                              message:error.message
                          })
                      }


}
}

module.exports=new ApiController()