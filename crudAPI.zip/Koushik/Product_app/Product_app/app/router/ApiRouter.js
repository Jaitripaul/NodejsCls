const express=require('express');
const ApiController = require('../controller/ApiController');
const router=express.Router();

router.post('/create',ApiController.create)
router.get('/get',ApiController.getdata)
router.get('/edit/:id',ApiController.edit)
router.post('/update/:id',ApiController.update)
router.delete('/delete/:id',ApiController.delete)



module.exports=router