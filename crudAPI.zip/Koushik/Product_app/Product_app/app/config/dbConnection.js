const mongoose=require('mongoose');


const dbcon=async()=>{
    try{

        const con=await mongoose.connect(process.env.MONGODB_URL);
        if(con)
        {
            console.log("DB Connect Successful");
            
        }
        else{
            console.log("Not Connect");
            
        }

    }
    catch(err)
    {
        console.log("Error in connection");
        
    }
}
module.exports=dbcon