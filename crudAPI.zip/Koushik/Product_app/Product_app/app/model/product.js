const mongoose=require('mongoose')
const Schema=mongoose.Schema


const ProductSchema=new Schema({
    name:{
        type:String,
        require:[true,"Name is Required"]
    },
    price:{
        type:Number,
        require:[true,"Number is Required"]
    },
   size:{
    type:[String],
    require:[true,"Size is Required"]
   },
   color:{
    type:[String],
    require:[true,"Color is Required"]
   },
   desc:{
    type:String,
     require:[true,"Desc is Required"]
   },
   brand:{
    type:String,
     require:[true,"Brand is Required"]
   }

})

const ProductModel=new mongoose.model('product',ProductSchema);
module.exports=ProductModel
