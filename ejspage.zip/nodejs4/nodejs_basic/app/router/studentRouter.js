const express=require('express')
const StudentController = require('../controller/StudentController')

const router=express.Router()



router.get('/',StudentController.studentpage)
router.get('/about',StudentController.aboutpage)

module.exports=router