class StudentController{

    async studentpage(req,res){
        
        res.render('student',{
            title:'studentpage',
            students:{
                sname:"Jaitri Paul",
                cls:"vi",
                rollNo:3
            }
        })
    }
    async aboutpage(req,res){
        //res.send('student page')
        res.render('about',{
            title:'about - page'
        })
    }

}

module.exports=new StudentController()
