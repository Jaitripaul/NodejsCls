const express=require('express')

const ejs=require('ejs')



const app=express()

app.set("view engine",'ejs')
app.set('views','views')




const studentRouter=require('./app/router/studentRouter')

app.use(studentRouter)




const port =3001

app.listen(port,()=>{
    console.log(`server is running port ${port}`);
    
})

