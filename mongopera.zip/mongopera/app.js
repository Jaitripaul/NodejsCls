require('dotenv').config(); //  Load .env first
const express = require('express');
const mongoose = require('mongoose');


const comparisonRoutes = require('./app/routes/comparisonRoutes');
const logicalRoutes = require('./app/routes/logicalRoutes'); 
const elementRoutes = require('./app/routes/elementRoutes');
const evaluationRoutes = require('./app/routes/evaluationRoutes');
const commentRoutes = require('./app/routes/commentRoutes');





const app = express();
const PORT = 3001;

// Middleware
app.use(express.json());

// MongoDB Connection
mongoose.connect(process.env.MONGODB_URL)
  .then(() => console.log(" MongoDB Connected"))
  .catch(err => console.error(" MongoDB error:", err));

// Routes
app.use('/api/comparison', comparisonRoutes);
app.use('/api/logical', logicalRoutes);
app.use('/api/element', elementRoutes);
app.use('/api/evaluation', evaluationRoutes);
app.use('/api/comment', commentRoutes);



// Server
app.listen(PORT, () => {
  console.log(` Server running on http://localhost:${PORT}`);
});
