// controllers/commentController.js
const User = require('../models/mongo');

exports.getUsersWithComment = async (req, res) => {
  try {
    const users = await User.find({ salary: { $gt: 30000 } })
      .comment("Fetching users with salary > 30000 for dashboard analysis"); // comment added

    res.json(users);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
};
