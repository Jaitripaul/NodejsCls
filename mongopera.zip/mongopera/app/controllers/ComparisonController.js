const User = require('../models/mongo');

// Create user
exports.createUser = async (req, res) => {
  try {
    const user = new User(req.body);
    const saved = await user.save();
    res.status(201).json(saved);
  } catch (err) {
    res.status(400).json({ error: err.message });
  }
};

// Get users with age > 25
exports.getUsersByAge = async (req, res) => {
  try {
    const users = await User.find({ age: { $gt: 25 } }); // comparison operator
    res.json(users);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
};

// Get users with salary between 30000 and 60000
exports.getUsersBySalaryRange = async (req, res) => {
  try {
    const users = await User.find({
      salary: { $gte: 30000, $lte: 60000 }
    });
    res.json(users);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
};
