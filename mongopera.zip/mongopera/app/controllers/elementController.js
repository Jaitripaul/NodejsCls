const User = require('../models/mongo');

// Get users where 'salary' field exists
exports.fieldExists = async (req, res) => {
  try {
    const users = await User.find({ salary: { $exists: true } });
    res.json(users);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
};

// Get users where 'age' is of type "int" (type code 16)
exports.fieldType = async (req, res) => {
  try {
    const users = await User.find({ age: { $type: 16 } }); // 16 = int
    res.json(users);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
};
