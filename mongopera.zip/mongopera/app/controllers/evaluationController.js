const User = require('../models/mongo');

// Find users whose name starts with "A" using $regex
exports.nameStartsWithA = async (req, res) => {
  try {
    const users = await User.find({ name: { $regex: /^A/, $options: 'i' } });
    res.json(users);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
};

// Find users with even age using $mod
exports.usersWithEvenAge = async (req, res) => {
  try {
    const users = await User.find({ age: { $mod: [2, 0] } });
    res.json(users);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
};

// Find users whose age is greater than salary using $expr
exports.ageGreaterThanSalary = async (req, res) => {
  try {
    const users = await User.find({
      $expr: { $gt: ["$age", "$salary"] }
    });
    res.json(users);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
};

// Find users with age > 25 using $where (not recommended in production)
exports.whereQuery = async (req, res) => {
  try {
    const users = await User.find({
      $where: function () {
        return this.age > 25;
      }
    });
    res.json(users);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
};
