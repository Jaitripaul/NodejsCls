const User = require('../models/mongo');

// Logical OR: age > 25 OR salary < 30000
exports.getUsersWithOr = async (req, res) => {
  try {
    const users = await User.find({
      $or: [
        { age: { $gt: 25 } },
        { salary: { $lt: 30000 } }
      ]
    });
    res.json(users);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
};

// Logical AND: age > 25 AND salary > 50000
exports.getUsersWithAnd = async (req, res) => {
  try {
    const users = await User.find({
      $and: [
        { age: { $gt: 25 } },
        { salary: { $gt: 50000 } }
      ]
    });
    res.json(users);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
};

// Logical NOR: neither age < 25 nor salary > 60000
exports.getUsersWithNor = async (req, res) => {
  try {
    const users = await User.find({
      $nor: [
        { age: { $lt: 25 } },
        { salary: { $gt: 60000 } }
      ]
    });
    res.json(users);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
};

// Logical NOT: age NOT > 30
exports.getUsersWithNot = async (req, res) => {
  try {
    const users = await User.find({
      age: { $not: { $gt: 30 } }
    });
    res.json(users);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
};
