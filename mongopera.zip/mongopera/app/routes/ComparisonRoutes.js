const express = require('express');
const router = express.Router();
const userController = require('../controllers/ComparisonController');

// Route to create a new user
router.post('/create', userController.createUser);

// Route to get users with age > 25
router.get('/age', userController.getUsersByAge);

// Route to get users within a salary range (e.g., salary > 30000)
router.get('/salary', userController.getUsersBySalaryRange);

module.exports = router;
