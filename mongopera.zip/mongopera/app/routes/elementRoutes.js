const express = require('express');
const router = express.Router();
const elementController = require('../controllers/elementController');

router.get('/exists', elementController.fieldExists);
router.get('/type', elementController.fieldType);

module.exports = router;
