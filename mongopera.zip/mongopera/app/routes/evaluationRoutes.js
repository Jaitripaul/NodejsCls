const express = require('express');
const router = express.Router();
const evaluationController = require('../controllers/evaluationController');

router.get('/name-starts-with-a', evaluationController.nameStartsWithA);
router.get('/even-age', evaluationController.usersWithEvenAge);
router.get('/age-gt-salary', evaluationController.ageGreaterThanSalary);
router.get('/where', evaluationController.whereQuery);

module.exports = router;
