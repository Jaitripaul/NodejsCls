const express = require('express');
const router = express.Router();
const logicalController = require('../controllers/LogicalController');

// Logical Operator Routes
router.get('/or', logicalController.getUsersWithOr);
router.get('/and', logicalController.getUsersWithAnd);
router.get('/nor', logicalController.getUsersWithNor);
router.get('/not', logicalController.getUsersWithNot);

module.exports = router;
