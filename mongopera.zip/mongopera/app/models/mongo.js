const mongoose = require('mongoose');

const mongoSchema = new mongoose.Schema({
  name: String,
  age: Number,
  salary: Number
});

module.exports = mongoose.model('mongo', mongoSchema);
