require("dotenv").config();
const express = require("express");
const app = express();

//body parser
app.use(express.json());
//database
const database = require("./app/config/dbConfig");
database();

//productroute
const productRoute = require("./app/router/productRouter");
app.use("/api/product", productRoute);

//userRoute
const userRoute = require("./app/router/userRoute");
app.use("/api/auth", userRoute);

//server
const port = 7000 || process.env.PORT;
app.listen(port, () => {
  console.log(`Server is runnig at port ${port}`);
});
