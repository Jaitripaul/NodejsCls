const mongoose = require("mongoose");

const dbconnect = async () => {
  try {
    const dbcon = await mongoose.connect(process.env.MONGODB_URL);
    if (dbcon) {
      console.log("Datbase Connected Sucessfully");
    } else {
      console.log("Database Not Connected");
    }
  } catch (err) {
    console.log(err.mesasge);
  }
};

module.exports=dbconnect;
