const bcrypt = require("bcryptjs");
const jwt = require("jsonwebtoken");

const hashePassword = (password) => {
  try {
    const salt = 10;
    const hashedPassword = bcrypt.hashSync(password, salt);
    return hashedPassword;
  } catch (err) {
    console.log(err);
  }
};

const comparePassword = (password, hashedPassword) => {
  return bcrypt.compare(password, hashedPassword);
};

const validateToken = async (req, res, next) => {
  let token;
  let authHeader = req.headers.Authorization || req.headers.authorization;
  if (authHeader && authHeader.startsWith("Bearer")) {
    token = authHeader.split(" ")[1];
     if (!token) {
    res.status(401).json({ message: "No token,Authorization Denied" });
  }
  try {
    const decode = jwt.verify(token, process.env.ACCESS_TOKEN_SECRET);
    req.user = decode;
    console.log("The decoded User is:", req.user);
    next();
  } catch (error) {
    res.status(400).json({
      message: "Token is not valid",
    });
  }
  }else{
     res.status(401).json({ message: "No token,Authorization Denied" });
  }

 
};

module.exports = { hashePassword, comparePassword, validateToken };
