const express = require("express");
const productController = require("../controller/productController");
const { validateToken } = require("../middleware/authApiCheck");
const authorizeRole = require("../middleware/roleMiddleWare");
const router = express.Router();

//Admin, Editor, User all three users can Acess
router.get("/", validateToken,authorizeRole("admin","editor","user"), productController.getAllproduct);

//Only Admin Can Acess
router.post("/create", validateToken,authorizeRole("admin") ,productController.createProduct);

//Both Admin and Editor Can Acess
router.put("/update", validateToken, authorizeRole("admin","editor"),productController.updateProduct);

//Only Admin Can Acess
router.delete("/delete", validateToken, authorizeRole("admin"),productController.deleteProduct);

module.exports = router;
