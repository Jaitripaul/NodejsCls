const Product = require("../model/productModel");

class ProdutController {
  async getAllproduct(req, res) {
    try {
      const product = await Product.find();
      res.status(201).json({
        product: {
          product,
        },
      });
    } catch (error) {
      res.status(500).json({
        message: error.message,
      });
    }
  }
  async createProduct(req, res) {
    try {
      const { name, brand, color, price } = req.body;
      const product = await Product.create({
        name,
        brand,
        color,
        price,
      });
      res.status(201).json({
        message: "Product Created Sucessfully",
        product: {
          product,
        },
      });
    } catch (error) {
      res.status(500).json({
        message: error.message,
      });
    }
  }

  async updateProduct(req, res) {
    try {
      const updated = await Product.findByIdAndUpdate(req.params.id, req.body, {
        new: true,
      });
      res.status(201).json({
        message: "Product Update Sucessfully",
        product: {
          updated,
        },
      });
    } catch (error) {
      res.status(500).json({
        message: error.message,
      });
    }
  }
  async deleteProduct(req, res) {
    try {
      await Product.findByIdAndDelete(req.params.id);
      res.json({ message: "Deleted" });
    } catch (error) {
      res.status(500).json({
        message: error.message,
      });
    }
  }
}

module.exports = new ProdutController();
