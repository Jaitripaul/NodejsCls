const User = require("../model/userModel");
const {
  hashePassword,
  comparePassword,
} = require("../middleware/authApiCheck");
const jwt = require("jsonwebtoken");
class UserController {
  async register(req, res) {
    try {
      const { username, password, role } = req.body;
      if (!username || !password || !role) {
        res.status(400).json({
          message: "All fields are requried",
        });
      }
      const hashedPassword = hashePassword(password);
      const newUser = new User({
        username,
        password: hashedPassword,
        role,
      });
      await newUser.save();
      res.status(201).json({
        message: `User register with username ${username}`,
        userifo: {
          newUser,
        },
      });
    } catch (error) {
      res.status(500).json({
        message: error.message,
      });
    }
  }
  async login(req, res) {
    try {
      const { username, password } = req.body;
      if (!username || !password) {
        res.status(400).json({
          message: "All fields are requried",
        });
      }
      const user = await User.findOne({ username });
      if (!user) {
        res.status(404).json({
          message: "User not found",
        });
      }
      const isMatch = comparePassword(password, user.password);
      if (!isMatch) {
        res.status(400).json({
          message: "Invalid Credentials",
        });
      }

      const token = jwt.sign(
        {
          id: user._id,
          role: user.role,
        },
        process.env.ACCESS_TOKEN_SECRET,
        { expiresIn: "10h" }
      );
      res.status(200).json({
        message: "Login Sucessfull",
        acessToken: token,
        userinfo: {
          id: user._id,
          role: user.role,
        },
      });
    } catch (error) {
      res.status(500).json({
        message: error.message,
      });
    }
  }
}

module.exports = new UserController();
