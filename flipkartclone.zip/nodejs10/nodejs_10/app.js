const express = require('express');
const mongoose = require('mongoose');
const path = require('path');
const app = express();

// MongoDB connection
mongoose.connect('mongodb+srv://Jaitripaul123:mh8za4Bc2UXWdBg8@cluster0.m8cmxti.mongodb.net/curdapplication')
  .then(() => console.log(' MongoDB connected'))
  .catch(err => console.error(' MongoDB connection error:', err));

// Middleware
app.use(express.urlencoded({ extended: true }));
app.use(express.static(path.join(__dirname, 'public')));
app.set('view engine', 'ejs');
app.set('views', path.join(__dirname, 'views')); //  if views/ is in root

// Routes
app.use('/', require('./app/routes/productRoutes'));

// Server
app.listen(3002, () => console.log(' Server running at http://localhost:3002'));
