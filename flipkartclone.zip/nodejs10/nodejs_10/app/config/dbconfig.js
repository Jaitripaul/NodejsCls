const mongoose = require('mongoose');
const Product = require('./app/models/Product');

mongoose.connect('mongodb://localhost:27017/searchFilterApp')
  .then(async () => {
    await Product.deleteMany();

    await Product.insertMany([
      {
        name: "Red Nike Shoes",
        size: ["M", "L"],
        color: ["Red"],
        brand: ["Nike"],
        price: 4000
      },
      {
        name: "Green Adidas T-Shirt",
        size: ["S", "M"],
        color: ["Green"],
        brand: ["Adidas"],
        price: 2500
      },
      {
        name: "Blue Puma Cap",
        size: ["S"],
        color: ["Blue"],
        brand: ["Puma"],
        price: 800
      },
      {
        name: "Blue Puma Cap",
        size: ["S"],
        color: ["Blue"],
        brand: ["Puma"],
        price: 800
      },
      {
        name: "Blue Puma Cap",
        size: ["S"],
        color: ["Blue"],
        brand: ["Puma"],
        price: 800
      },
      {
        name: "Adidas Cap",
        size: ["S","M"],
        color: ["Blue"],
        brand: ["Adidas"],
        price: 800
      },
      {
        name: "Blue Puma Cap",
        size: ["S"],
        color: ["Blue"],
        brand: ["Puma"],
        price: 800
      },
      {
        name: "Blue Puma Cap",
        size: ["S"],
        color: ["Blue"],
        brand: ["Puma"],
        price: 800
      },
      {
        name: "Blue Puma Cap",
        size: ["S"],
        color: ["Blue"],
        brand: ["Puma"],
        price: 800
      },
      {
        name: "Nike Cap",
        size: ["S"],
        color: ["Blue"],
        brand: ["Nike"],
        price: 800
      },
      {
        name: "Puma Cap",
        size: ["M"],
        color: ["Red"],
        brand: ["Puma"],
        price: 1000
      },

    ]);

    console.log("Sample data inserted.");
    mongoose.disconnect();
  });
