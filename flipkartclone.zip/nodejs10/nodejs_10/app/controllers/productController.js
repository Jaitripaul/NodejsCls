const Product = require('../models/Product');

exports.index = async (req, res) => {
  let { brand, color, size, minPrice, maxPrice } = req.query;

  const query = {};

  if (brand) query.brand = { $in: Array.isArray(brand) ? brand : [brand] };
  if (color) query.color = { $in: Array.isArray(color) ? color : [color] };
  if (size) query.size = { $in: Array.isArray(size) ? size : [size] };

  if (minPrice || maxPrice) {
    query.price = {};
    if (minPrice) query.price.$gte = +minPrice;
    if (maxPrice) query.price.$lte = +maxPrice;
  }

  const products = await Product.find(query);
  res.render('index', { products });
};
exports.showAddForm = (req, res) => {
  res.render('add');
};

exports.addProduct = async (req, res) => {
  const { name, brand, color, size, price } = req.body;
  const image = req.file ? req.file.filename : '';
  const product = new Product({ name, brand, color, size, price, image });
  await product.save();
  res.redirect('/');
};
exports.deleteProduct = async (req, res) => {
  try {
    await Product.findByIdAndDelete(req.params.id);
    res.redirect('/');
  } catch (err) {
    res.status(500).send('Delete failed');
  }
};
