const express = require("express");
const mongoose = require("mongoose");
const bodyParser = require("body-parser");
const methodOverride = require("method-override");
const path = require("path");
const taskRoutes = require("./app/routes/taskRoutes");
require("dotenv").config();

const dbcon = require("./app/config/dbconfig");
dbcon();

const app = express();


// ✅ Middleware
app.use(bodyParser.urlencoded({ extended: true }));
app.use(methodOverride("_method"));
app.use(express.static(path.join(__dirname, "app/public")));
app.set("view engine", "ejs");
app.set("views", path.join(__dirname, "views")); // Ensures EJS views are found

// ✅ Routes
app.use("/", taskRoutes);

app.use(express.urlencoded({ extended: true })); // For form submissions
app.use(express.json()); // For JSON requests

// ✅ Start server
const PORT = process.env.PORT || 3001;
app.listen(PORT, () => {
  console.log(`🚀 Server running at http://localhost:${PORT}`);
});
