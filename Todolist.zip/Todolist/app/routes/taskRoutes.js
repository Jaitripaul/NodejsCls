const express = require("express");
const router = express.Router();
const taskController = require("../controllers/taskController");

// Show new task form
router.get("/new", (req, res) => {
    res.render("new"); // render new.ejs
});

// CRUD routes
router.get("/", taskController.getTasks);
router.post("/", taskController.createTask);
router.put("/complete/:id", taskController.completeTask);
router.get("/edit/:id", taskController.editTask);
router.put("/edit/:id", taskController.updateTask);

router.get("/:id", taskController.deleteTask);

module.exports = router;
