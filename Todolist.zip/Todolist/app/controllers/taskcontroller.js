const Task = require("../models/Task");

// Get all tasks
async function getTasks(req, res) {
    try {
        const tasks = await Task.find().sort({ createdAt: -1 });
        res.render("index", { tasks });
    } catch (err) {
        console.error("Error fetching tasks:", err);
        res.status(500).send("Server Error");
    }
}

// Create a new task
async function createTask(req, res) {
    try {
        const { title } = req.body;
        if (!title || !title.trim()) {
            return res.redirect("/");
        }
        await Task.create({ title: title.trim(), completed: false });
        res.redirect("/");
    } catch (err) {
        console.error("Error creating task:", err);
        res.status(500).send("Server Error");
    }
}

// Mark a task as completed
async function completeTask(req, res) {
    try {
        const { id } = req.params;
        const task = await Task.findById(id);

        if (!task) {
            console.error(`Task not found with id: ${id}`);
            return res.redirect("/");
        }

        task.completed = true;
        await task.save();

        res.redirect("/");
    } catch (err) {
        console.error("Error completing task:", err);
        res.status(500).send("Server Error");
    }
}

// Edit a task title
async function editTask(req, res) {
    try {
        const task = await Task.findById(req.params.id);
        if (!task) {
            return res.redirect("/");
        }
        res.render("edit", { task });
    } catch (err) {
        console.error(err);
        res.redirect("/");
    }
}

// Handle update after edit form submission
async function updateTask(req, res) {
    try {
        const { id } = req.params;
        const { title } = req.body;

        if (!title || !title.trim()) {
            return res.redirect(`/edit/${id}`);
        }

        const task = await Task.findByIdAndUpdate(
            id,
            { title: title.trim() },
            { new: true }
        );

        if (!task) {
            console.error(`Task not found with id: ${id}`);
            return res.redirect("/");
        }

        res.redirect("/");
    } catch (err) {
        console.error("Error updating task:", err);
        res.status(500).send("Server Error");
    }
}


// Delete a task
async function deleteTask(req, res) {
    try {
        await Task.findByIdAndDelete(req.params.id);
        res.redirect("/");
    } catch (err) {
        console.error(err);
        res.status(500).send("Server Error");
    }
}

module.exports = {
    getTasks,
    createTask,
    completeTask,
    editTask,
    updateTask,
    deleteTask
};
